// MT5 Trade Extractor - Content Script
// Scrapes trade history from MetaTrader 5 Web Terminal

(function () {
  "use strict";

  const isActualTrade = (t) => {
    if (!t) return false;
    if (!t.ticket) return false;
    const ticketStr = String(t.ticket).trim();
    
    // Strip leading/trailing ellipses, dots, and spaces
    const cleanedTicket = ticketStr.replace(/^[.\s…]+|[.\s…]+$/g, '').replace(/\s/g, '');
    
    // Real ticket number never contains a minus sign or a decimal point
    if (/[.\-–—]/.test(cleanedTicket)) return false;
    
    // Must be a pure digit string of at least 5 digits
    if (!/^\d{5,}$/.test(cleanedTicket)) return false;
    
    // Must not be a balance modification type
    const ignoreTypes = ["balance", "deposit", "credit", "withdrawal"];
    if (t.type && ignoreTypes.includes(t.type.toLowerCase().trim())) return false;
    
    return true;
  };

  // Listen for messages from the popup
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "extractTrades") {
      const count = request.count; // number of trades to extract (null = all)
      const historical = !!request.historical;
      
      // Auto-scroll logic if requested
      if (request.autoScroll) {
        // Acknowledge receipt from this frame
        chrome.runtime.sendMessage({ action: "extractAck" });
        
        autoScrollAndExtract(count, historical).then((trades) => {
          chrome.runtime.sendMessage({ action: "tradesExtracted", trades: trades, isFinal: true });
        }).catch((err) => {
          chrome.runtime.sendMessage({ action: "tradesExtracted", trades: [], isFinal: true, error: err.message });
        });
        return false; // Do not use sendResponse
      }

      // Legacy synchronous extract
      const trades = extractTradesFromPage(count, historical);
      if (trades.length > 0) {
        chrome.runtime.sendMessage({ action: "tradesExtracted", trades: trades, isFinal: true });
      } else {
        chrome.runtime.sendMessage({ action: "tradesExtracted", trades: [], isFinal: true });
      }
      return false;
    } else if (request.action === "ping") {
      sendResponse({ alive: true });
    }
    return true; // keep message channel open for async
  });

  function extractTradesFromPage(count, historical = false, skipDedup = false) {
    let trades = [];

    // ─── Strategy S: Svelte div-table ────────────────────────────────────────
    // MT5 Web Terminal (e.g. mt5.the5ers.com) uses Svelte-rendered div-tables:
    //   .table / .tbody / .tr / .td / .th  (no <table> elements, no AG Grid).
    // Svelte renders ALL rows directly into the DOM — no virtual scrolling —
    // so a single querySelectorAll captures the complete trade list at once.
    trades = tryExtractFromSvelteTable();

    if (trades.length === 0 && historical) {
      // ─── Strategy 0: AG Grid (MT5 Web Terminal) ─── MUST run first
      // AG Grid splits one logical row across multiple DOM containers (pinned-left
      // + center viewports). tryExtractStructured() cannot merge those fragments
      // — it reads whichever partial fragment it finds first, producing rows with
      // wrong column alignment that puts commission into closePrice/tp.
      trades = tryExtractFromAgGrid();

      // ─── Strategy -1: Column-position-aware structured extractor ───
      // Only reached when no AG Grid is present on the page.
      if (trades.length === 0) {
        trades = tryExtractStructured();
      }
    }

    // ─── Strategy 1: Heuristic DOM Row Scraper ───
    // Skip entirely when AG Grid is present: the text-node walker cannot cross
    // the pinned/center viewport boundary, so it produces partial rows.
    if (trades.length === 0 && !document.querySelector('.ag-root, .ag-root-wrapper')) {
      trades = tryExtractFromHeuristicDOM();
    }

    // ─── Strategy 2: MT5 Web Terminal (metatrader5.com / official web) ───
    if (trades.length === 0) {
      trades = tryExtractFromWebTerminal();
    }

    // ─── Strategy 3: Generic table rows if Strategy 2 fails ───
    if (trades.length === 0) {
      trades = tryExtractFromGenericTable();
    }

    // ─── Strategy 4: Scrape visible text and parse manually ───
    if (trades.length === 0) {
      trades = tryExtractFromVisibleText();
    }

    const hasAnyField = (t) => {
      if (!t) return false;
      return !!(t.ticket || t.openTime || t.closeTime || t.symbol || t.profit !== undefined || t.commission !== undefined || t.swap !== undefined || t.fee !== undefined);
    };

    // Filter trades - keep all rows containing any fields (including balance and summary rows) and make sure it is an actual trade
    trades = trades.filter((t) => hasAnyField(t) && isActualTrade(t));

    // Sort newest first (latest to oldest based on closeTime, then openTime)
    trades.sort((a, b) => {
      const timeA = a.closeTime || a.openTime || '';
      const timeB = b.closeTime || b.openTime || '';
      if (timeA < timeB) return 1;
      if (timeA > timeB) return -1;
      return 0;
    });

    // skipDedup=true when called from scroll loop — dedup runs once on the full
    // accumulated list at the end of autoScrollAndExtract instead.
    if (historical && !skipDedup) {
      trades = deduplicatePartialCloses(trades);
    }

    trades = trades.filter(isActualTrade);

    if (count && count > 0) {
      trades = trades.slice(0, count);
    }

    return trades;
  }

  // ─── Auto-scroll + Page-Context Logic ──────────────────────────────────
  async function autoScrollAndExtract(count, historical = false) {
    // Wait up to 15 s for trade rows to appear (slow loading/scrapping support)
    if (historical) {
      const rowsExist = () => {
        // AG Grid
        if (document.querySelectorAll('.ag-row:not(.ag-row-empty)').length > 0) return true;
        // Standard HTML table
        if (document.querySelectorAll('tbody tr').length > 0) return true;
        // Svelte class-based
        if (document.querySelectorAll('.tbody .tr').length > 0) return true;
        if (Array.from(document.querySelectorAll('.tr')).some(r => r.querySelectorAll('.td').length >= 4)) return true;
        // Content-based: any element whose DIRECT children include both a
        // buy/sell cell and a MT5 timestamp — works for ANY class naming scheme
        const tsRe   = /\d{4}[.\/-]\d{2}[.\/-]\d{2}\s+\d{2}:\d{2}/;
        const typeRe = /\b(buy|sell)\b/i;
        for (const el of document.querySelectorAll('*')) {
          if (el.children.length < 4 || el.children.length > 20) continue;
          const texts = Array.from(el.children).map(c => (c.innerText || '').trim());
          if (texts.some(t => typeRe.test(t)) && texts.some(t => tsRe.test(t))) return true;
        }
        return false;
      };
      // Wait up to 15 seconds (75 * 200ms)
      for (let i = 0; i < 75 && !rowsExist(); i++) {
        await new Promise(r => setTimeout(r, 200));
      }
    }

    // ── Method 1: Page-context AG Grid API injection ──────────────────────
    // ONLY run when AG Grid is actually present on the page.
    if (document.querySelector('.ag-root, .ag-root-wrapper')) {
      const pageResult = await extractAllRowsViaPageScript();
      if (pageResult && pageResult.ok && pageResult.rows && pageResult.rows.length > 0) {
        let trades = convertPageRows(pageResult.rows, pageResult.cols);
        trades = finishTrades(trades, count, historical);
        if (trades.length > 0) return trades;
      }
    }

    // ── Method 1.5: Direct DOM read (no scroll needed when ALL rows are in DOM) ─
    // Svelte renders every history row into the DOM at once — no virtual scroll.
    // Try extracting before starting the scroll loop; if we get trades AND no
    // scroll container exists, we're done immediately.
    {
      const directTrades = extractTradesFromPage(count, historical);
      if (directTrades.length > 0) {
        const sc = findScrollContainer();
        if (!sc) return directTrades;          // no scroll container → all data is here
        // Has a scroll container → might be virtual-scrolled; keep going
      }
    }

    // ── Method 2: Scroll-based fallback ─────────────────────────────────────
    let allTrades = [];
    const seenKeys = new Set();

    let scrollContainer = findScrollContainer();
    if (!scrollContainer) {
      for (let attempt = 0; attempt < 5; attempt++) {
        const trades = extractTradesFromPage(count, historical);
        if (trades.length > 0) return trades;
        if (attempt < 4) await new Promise(r => setTimeout(r, 600));
      }
      return [];
    }

    const tradeKey = (t) =>
      `${t.ticket || ''}|${t.openTime || ''}|${t.closeTime || ''}|${t.symbol || ''}`;

    const collectBatch = (batch) => {
      for (const t of batch) {
        const key = tradeKey(t);
        if (!t.ticket && !t.openTime && !t.closeTime && !t.symbol) continue;
        if (!seenKeys.has(key)) { seenKeys.add(key); allTrades.push(t); }
      }
    };

    const setScrollTop = (container, top) => {
      if (container === document.documentElement || container === document.body) {
        window.scrollTo(0, top);
      } else {
        container.scrollTop = top;
      }
    };

    const getScrollHeight = (container) => {
      if (container === document.documentElement || container === document.body) {
        return document.documentElement.scrollHeight || document.body.scrollHeight;
      }
      return container.scrollHeight;
    };

    // If a count limit is requested, perform a fast top-bottom scan
    if (count && count > 0) {
      const originalScrollTop = getScrollTop(scrollContainer);

      // 1. Scan at the top
      setScrollTop(scrollContainer, 0);
      await new Promise(r => setTimeout(r, 400));
      collectBatch(extractTradesFromPage(null, historical, true));

      // 2. Scan at the bottom
      const maxScroll = getScrollHeight(scrollContainer);
      setScrollTop(scrollContainer, maxScroll);
      await new Promise(r => setTimeout(r, 450));
      collectBatch(extractTradesFromPage(null, historical, true));

      // 3. Restore scroll position
      setScrollTop(scrollContainer, originalScrollTop);

      // Post-process: filter, sort, slice
      allTrades = finishTrades(allTrades, count, historical);
      return allTrades;
    }

    const getScrollTop = (container) => {
      if (container === document.documentElement || container === document.body) {
        return window.scrollY;
      }
      return container.scrollTop;
    };

    const doScroll = (container, step) => {
      if (container === document.documentElement || container === document.body) {
        const prevY = window.scrollY;
        window.scrollBy(0, step);
        return window.scrollY - prevY;
      } else {
        const prevTop = container.scrollTop;
        container.scrollTop += step;
        return container.scrollTop - prevTop;
      }
    };

    // Reset scroll to top
    if (scrollContainer === document.documentElement || scrollContainer === document.body) {
      window.scrollTo(0, 0);
    } else {
      scrollContainer.scrollTop = 0;
    }
    await waitForAgGridRows(scrollContainer, 800);

    const rowHeight = measureRowHeight(scrollContainer) || 30;
    // Slower, safer scroll step: 3 rows at a time
    const scrollStep = rowHeight * 3;

    while (true) {
      const prevSize = allTrades.length;
      const currentBatch = extractTradesFromPage(null, historical, true);
      collectBatch(currentBatch);

      // Send intermediate progress back to popup in real-time
      chrome.runtime.sendMessage({ 
        action: "tradesExtracted", 
        trades: currentBatch, 
        isFinal: false 
      });

      const prevTop = getScrollTop(scrollContainer);
      const scrolledAmount = doScroll(scrollContainer, scrollStep);
      const moved = Math.abs(scrolledAmount) >= 2;

      if (!moved) {
        // We hit the bottom or couldn't scroll further.
        // Wait a bit to see if more rows load dynamically (WebSocket delay support)
        let loadedMore = false;
        for (let waitAttempt = 0; waitAttempt < 5; waitAttempt++) {
          await new Promise(r => setTimeout(r, 500));
          
          // Try to extract in case rows loaded in place
          const newBatch = extractTradesFromPage(null, historical, true);
          collectBatch(newBatch);
          
          const retryScrolled = doScroll(scrollContainer, scrollStep);
          if (Math.abs(retryScrolled) >= 2 || allTrades.length > prevSize) {
            loadedMore = true;
            break;
          }
        }
        if (!loadedMore) {
          // Definitely at the absolute bottom and no more rows loaded
          break;
        }
      }

      // Wait a flat 350ms after each scroll step to let the Svelte/virtual list DOM update
      await new Promise(r => setTimeout(r, 350));
    }

    collectBatch(extractTradesFromPage(null, historical, true));
    allTrades = finishTrades(allTrades, count, historical);
    return allTrades;
  }

  // Shared post-processing: sort → dedup → slice
  function finishTrades(trades, count, historical) {
    trades = trades.filter(isActualTrade);
    trades.sort((a, b) => {
      const tA = a.closeTime || a.openTime || '';
      const tB = b.closeTime || b.openTime || '';
      if (!tA && tB) return -1; // place summary/empty-time rows at the top
      if (tA && !tB) return 1;
      return tA < tB ? 1 : tA > tB ? -1 : 0;
    });
    if (historical) trades = deduplicatePartialCloses(trades);
    if (count && count > 0) {
      trades = trades.slice(0, count);
    }
    return trades;
  }

  // ─── Page-Context Injection ───────────────────────────────────────────────
  // Injects a <script> that runs in the PAGE's JS scope (not the isolated
  // content-script scope) so it can access the AG Grid component attached to
  // the DOM. Returns {ok, rows[], cols[]} via CustomEvent.
  function extractAllRowsViaPageScript() {
    return new Promise((resolve) => {
      const token = '__mt5x' + Math.random().toString(36).slice(2, 9);
      const timer = setTimeout(() => resolve(null), 8000);

      document.addEventListener(token, function handler(e) {
        clearTimeout(timer);
        document.removeEventListener(token, handler);
        resolve(e.detail || null);
      }, { once: true });

      // This code runs in the PAGE context and can access window / AG Grid API
      const code = `(function(){
        var T='${token}';
        function fire(d){document.dispatchEvent(new CustomEvent(T,{detail:d}));}

        function findApi(){
          // Try every .ag-root-wrapper/.ag-root element on the page
          var roots=Array.from(document.querySelectorAll('.ag-root-wrapper,.ag-root'));
          for(var i=0;i<roots.length;i++){
            var el=roots[i];
            var names=Object.getOwnPropertyNames(el);
            for(var j=0;j<names.length;j++){
              try{
                var v=el[names[j]];
                if(!v||typeof v!=='object')continue;
                // Direct API (various AG Grid versions)
                if(typeof v.forEachNode==='function'&&typeof v.getModel==='function')return v;
                // Wrapped in .api
                if(v.api&&typeof v.api.forEachNode==='function'&&typeof v.api.getModel==='function')return v.api;
                // Wrapped in .gridOptions.api (older versions)
                if(v.gridOptions&&v.gridOptions.api&&typeof v.gridOptions.api.forEachNode==='function')return v.gridOptions.api;
                // Angular/React component ref
                if(v.gridOptions&&v.gridOptions.api)return v.gridOptions.api;
              }catch(ex){}
            }
          }
          // Fallback: search window for any gridApi objects
          var wkeys=Object.keys(window);
          for(var k=0;k<wkeys.length;k++){
            try{
              var w=window[wkeys[k]];
              if(w&&typeof w.forEachNode==='function'&&typeof w.getModel==='function')return w;
            }catch(ex){}
          }
          return null;
        }

        function getColDefs(api){
          var cols=[];
          try{
            var cd=api.getColumnDefs?api.getColumnDefs():null;
            if(!cd)cd=api.getColumns?api.getColumns().map(function(c){return c.getColDef();}):null;
            if(cd)for(var i=0;i<cd.length;i++){
              if(cd[i]&&cd[i].field!==undefined)
                cols.push({field:String(cd[i].field),header:String(cd[i].headerName||cd[i].headerValueGetter||cd[i].field||'')});
            }
          }catch(ex){}
          return cols;
        }

        try{
          var api=findApi();
          if(!api){fire({ok:false,err:'no-api-found',rows:[],cols:[]});return;}

          // Collect ALL row data (includes off-screen virtualised rows)
          var rows=[];
          api.forEachNode(function(node){
            if(node&&node.data){
              try{rows.push(JSON.parse(JSON.stringify(node.data)));}
              catch(ex){rows.push(node.data);}
            }
          });

          var cols=getColDefs(api);
          fire({ok:true,rows:rows,cols:cols,total:rows.length});
        }catch(ex){
          fire({ok:false,err:ex.message,rows:[],cols:[]});
        }
      })();`;

      const s = document.createElement('script');
      s.textContent = code;
      (document.head || document.documentElement).appendChild(s);
      s.remove();
    });
  }

  // Convert raw AG Grid node.data objects → our standard trade format.
  // Uses column definitions (field→headerName) to do the mapping, with a
  // fallback that tries common field name patterns directly.
  function convertPageRows(rows, cols) {
    if (!rows || rows.length === 0) return [];
    const trades = [];

    // Build an ordered map: dataFieldName → ourFieldName
    // Ordered so that duplicate headers (Time×2, Price×2) fire the counter correctly
    let orderedMap = null;
    if (cols && cols.length > 0) {
      orderedMap = [];
      const counts = {};
      for (const col of cols) {
        if (!col.field) continue;
        const ourField = headerToField(col.header || col.field, counts);
        orderedMap.push({ dataField: col.field, ourField });
      }
    }

    // Direct field-name heuristics for when no colDefs are available
    const directHeuristic = {
      ticket:'ticket', deal:'ticket', id:'ticket', order:'ticket', position:'ticket',
      type:'type', direction:'type', side:'type',
      volume:'volume', lots:'volume', size:'volume',
      symbol:'symbol', instrument:'symbol',
      opentime:'openTime', open_time:'openTime',
      closetime:'closeTime', close_time:'closeTime',
      openprice:'openPrice', open_price:'openPrice',
      closeprice:'closePrice', close_price:'closePrice',
      sl:'sl', stoploss:'sl', stop_loss:'sl',
      tp:'tp', takeprofit:'tp', take_profit:'tp',
      commission:'commission', comm:'commission',
      fee:'fee', swap:'swap',
      profit:'profit', pnl:'profit', net_profit:'profit',
      comment:'comment', note:'comment',
    };

    for (const row of rows) {
      const trade = {};

      if (orderedMap) {
        // Column-definition path (most accurate, handles Time×2 / Price×2)
        for (const { dataField, ourField } of orderedMap) {
          if (!ourField) continue;
          const raw = row[dataField];
          if (raw === null || raw === undefined || raw === '') continue;
          applyField(trade, ourField, raw);
        }
      } else {
        // Heuristic path
        for (const [key, raw] of Object.entries(row)) {
          if (raw === null || raw === undefined || raw === '') continue;
          const k = key.toLowerCase().replace(/[^a-z0-9]/g, '_').replace(/_+/g, '_');
          const ourField = directHeuristic[k];
          if (ourField) applyField(trade, ourField, raw);
        }
        // Handle ambiguous 'time' and 'price' keys (appear twice in MT5)
        const keys = Object.keys(row);
        let timeCount = 0, priceCount = 0;
        for (const key of keys) {
          const k = key.toLowerCase();
          if (k === 'time' || k === 'datetime') {
            timeCount++;
            const ourField = timeCount === 1 ? 'openTime' : 'closeTime';
            if (!trade[ourField] && row[key] != null && row[key] !== '')
              trade[ourField] = String(row[key]);
          }
          if (k === 'price') {
            priceCount++;
            const ourField = priceCount === 1 ? 'openPrice' : 'closePrice';
            if (!trade[ourField] && row[key] != null && row[key] !== '') {
              const v = typeof row[key] === 'number' ? row[key] : cleanNumber(String(row[key]));
              if (v !== undefined) trade[ourField] = v;
            }
          }
        }
      }

      if (trade.ticket || trade.openTime) trades.push(trade);
    }

    return trades;
  }

  function applyField(trade, ourField, raw) {
    if (NUMERIC_FIELDS.has(ourField)) {
      const v = typeof raw === 'number' ? raw : cleanNumber(String(raw));
      if (v !== undefined) trade[ourField] = v;
    } else if (ourField === 'type') {
      trade.type = String(raw).toLowerCase().trim();
    } else if (ourField === 'symbol') {
      trade.symbol = String(raw).replace(/\.$/, '').toUpperCase().trim();
    } else {
      trade[ourField] = String(raw).trim();
    }
  }

  // Wait until AG Grid has finished rendering after a scroll.
  // Polls the rendered row count every 150 ms; returns when it has been
  // stable for two consecutive polls OR after maxWaitMs, whichever comes first.
  async function waitForAgGridRows(scrollContainer, minWaitMs) {
    await new Promise(r => setTimeout(r, minWaitMs));
    let prev = -1;
    let stable = 0;
    for (let i = 0; i < 20; i++) {      // max extra 3 s (20 × 150 ms)
      await new Promise(r => setTimeout(r, 150));
      // Count both AG Grid rows AND Svelte div-table rows for stability detection
      const cur =
        scrollContainer.querySelectorAll('.ag-row:not(.ag-row-empty)').length +
        scrollContainer.querySelectorAll('.tr').length;
      if (cur === prev) {
        stable++;
        if (stable >= 2) return;        // stable for 300 ms → done
      } else {
        stable = 0;
      }
      prev = cur;
    }
  }

  // Measure the pixel height of one row by comparing adjacent rows' bounding rects.
  function measureRowHeight(scrollContainer) {
    // Try AG Grid rows first, fall back to Svelte div-table data rows
    let rows = Array.from(scrollContainer.querySelectorAll('.ag-row:not(.ag-row-empty)'));
    if (rows.length < 2) {
      rows = Array.from(scrollContainer.querySelectorAll('.tr'))
        .filter(r => !r.querySelector('.th') && r.querySelectorAll('.td').length >= 4);
    }
    if (rows.length < 2) return null;
    const r0 = rows[0].getBoundingClientRect();
    const r1 = rows[1].getBoundingClientRect();
    const h = Math.abs(r1.top - r0.top);
    return h > 5 ? h : null;
  }

  // Find the .ag-body-viewport that belongs to the TRADE history grid by
  // anchoring on an actual trade row and walking up the DOM tree.
  // This is the only reliable way when the page has multiple AG Grid instances.
  // Probe whether an element can actually be scrolled by temporarily
  // nudging its scrollTop. More reliable than CSS overflow checks because
  // it works regardless of which overflow value the browser reports.
  function isScrollable(el) {
    if (!el || el === document.body || el === document.documentElement) return false;
    if (el.scrollHeight <= el.clientHeight + 20) return false;
    const prev = el.scrollTop;
    el.scrollTop += 1;
    const moved = el.scrollTop !== prev;
    el.scrollTop = prev;
    return moved;
  }

  function findScrollContainer() {
    // ── Priority 0: Svelte-specific scroll container elements ──────────────
    const tbody = document.querySelector('.tbody');
    if (tbody) {
      if (tbody.scrollHeight > tbody.clientHeight + 5) return tbody;
      const p = tbody.parentElement;
      if (p && p.scrollHeight > p.clientHeight + 5) return p;
    }

    // ── Priority 1: walk up from the trade row, probe each ancestor ───────
    // findAgTradeRow() now finds both AG Grid rows AND Svelte div-table rows.
    // We probe each ancestor with a 1-px scrollTop nudge: if it moves, it's
    // the scroll container.  This handles every overflow CSS variant
    // (auto, scroll, overlay, clip, …) without needing to check the property.
    const tradeRow = findAgTradeRow();
    if (tradeRow) {
      let el = tradeRow.parentElement;
      while (el && el !== document.body) {
        if (isScrollable(el)) return el;
        // Also accept known AG Grid viewport classes even if probe fails
        if (el.classList.contains('ag-body-viewport') ||
            el.classList.contains('ag-center-cols-viewport')) {
          if (el.scrollHeight > el.clientHeight + 5) return el;
        }
        el = el.parentElement;
      }
    }

    // ── Priority 2: any scrollable .ag-body-viewport ──────────────────────
    for (const vp of document.querySelectorAll('.ag-body-viewport, .ag-center-cols-viewport')) {
      if (vp.scrollHeight > vp.clientHeight + 5) return vp;
    }

    // ── Priority 3: heuristic scrollable ancestor of a ticket element ─────
    const ticketRegex = /\b\d{6,10}\b/;
    const typeRegex = /\b(buy|sell|balance|deposit|credit)\b/i;
    for (const el of document.getElementsByTagName('*')) {
      if (el.children.length !== 0) continue;
      const text = (el.innerText || '').trim();
      if (!ticketRegex.test(text)) continue;
      let parent = el.parentElement;
      for (let lvl = 0; lvl < 4 && parent; lvl++, parent = parent.parentElement) {
        if (typeRegex.test(parent.innerText || '')) {
          let up = parent.parentElement;
          while (up && up !== document.body) {
            if (up.scrollHeight > up.clientHeight + 5) {
              const s = window.getComputedStyle(up);
              if (s.overflowY === 'auto' || s.overflowY === 'scroll' ||
                  s.overflow === 'auto' || s.overflow === 'overlay') return up;
            }
            up = up.parentElement;
          }
          break;
        }
      }
    }

    // ── Priority 4: document fallback ─────────────────────────────────────
    if (document.documentElement.scrollHeight > document.documentElement.clientHeight + 5)
      return document.documentElement;
    if (document.body.scrollHeight > document.body.clientHeight + 5)
      return document.body;

    return null;
  }

  // Find a visible .ag-row that contains trade data (a buy/sell cell or ticket number).
  function findAgTradeRow() {
    const TYPE_RE = /\b(buy|sell)\b/i;   // word-boundary: matches "buy", "sell", "buy limit"
    const TKT_RE  = /\b\d{7,10}\b/;     // word-boundary: matches ticket even with trailing chars
    const TS_RE   = /\d{4}[.\/-]\d{2}[.\/-]\d{2}\s+\d{2}:\d{2}/;

    // AG Grid rows
    for (const row of document.querySelectorAll('.ag-row:not(.ag-row-empty)')) {
      if (row.closest('.ag-header')) continue;
      for (const cell of row.querySelectorAll('.ag-cell')) {
        const t = (cell.innerText || '').trim();
        if (TYPE_RE.test(t) || TKT_RE.test(t)) return row;
      }
    }
    // Svelte class-based rows
    for (const row of document.querySelectorAll('.tr')) {
      if (row.querySelector('.th')) continue;
      for (const cell of row.querySelectorAll('.td')) {
        const t = (cell.innerText || '').trim();
        if (TYPE_RE.test(t) || TKT_RE.test(t)) return row;
      }
    }
    // Content-based fallback: any element whose direct children include
    // a timestamp + buy/sell + ticket — works with any class naming scheme
    for (const el of document.getElementsByTagName('*')) {
      if (el.children.length < 8 || el.children.length > 20) continue;
      const texts = Array.from(el.children).map(c => (c.innerText || '').trim());
      if (texts.some(t => TYPE_RE.test(t)) &&
          texts.some(t => TKT_RE.test(t))  &&
          texts.some(t => TS_RE.test(t)))    return el;
    }
    return null;
  }

  // ─── Deduplicate partial-close "sum" trades ─────────────────────────────
  // When a trade is partially closed, MT5 generates individual deal entries
  // (e.g. two rows for 562120215 and 562120216) AND sometimes also renders a
  // combined summary row (e.g. 7549388) whose profit ≈ sum of the partials and
  // whose volume = sum of the partials. This function detects and removes the
  // combined duplicate so the user sees only the individual partial closes.
  function deduplicatePartialCloses(trades) {
    if (trades.length < 3) return trades;

    const normSym = (s) => String(s || '').toUpperCase().replace(/[.\s]+$/, '');
    const EPS_PROFIT = 0.15;  // rounding tolerance in currency units
    const EPS_VOL    = 0.0001;

    const toRemove = new Set();

    for (let i = 0; i < trades.length; i++) {
      if (toRemove.has(i)) continue;
      const t = trades[i];
      if (!isActualTrade(t)) continue;
      if (t.profit === undefined || t.volume === undefined) continue;

      const sym  = normSym(t.symbol);
      const type = (t.type || '').toLowerCase();

      // Collect peer trades with matching normalised symbol and direction
      const peers = [];
      for (let j = 0; j < trades.length; j++) {
        if (j === i || toRemove.has(j)) continue;
        const u = trades[j];
        if (!isActualTrade(u)) continue;
        if (u.profit === undefined || u.volume === undefined) continue;
        if (normSym(u.symbol) !== sym) continue;
        if ((u.type || '').toLowerCase() !== type) continue;
        peers.push(j);
      }

      // Check all pairs of peers — if any pair sums to this trade, it's a duplicate
      let isDuplicate = false;
      outer: for (let a = 0; a < peers.length; a++) {
        for (let b = a + 1; b < peers.length; b++) {
          const pa = trades[peers[a]], pb = trades[peers[b]];
          if (
            Math.abs(t.profit - (pa.profit + pb.profit)) <= EPS_PROFIT &&
            Math.abs(t.volume - (pa.volume + pb.volume)) <= EPS_VOL
          ) {
            isDuplicate = true;
            break outer;
          }
        }
      }

      if (isDuplicate) toRemove.add(i);
    }

    return trades.filter((_, i) => !toRemove.has(i));
  }

  // ─── Robust number cleaner ──────────────────────────────────────────────
  // MT5 uses a SPACE as the thousands separator ("4 550.13") and "." for the
  // decimal. parseFloat("4 550.13") === 4, so we must strip spaces & thousands
  // commas before parsing. Returns undefined for blank/non-numeric cells so a
  // blank column stays blank instead of defaulting to 0.
  function cleanNumber(s) {
    if (s == null) return undefined;
    let str = String(s).trim();
    if (str === "" || str === "—" || str === "-" || str === "–") return undefined;
    // Remove spaces (thin/regular) used as thousand separators and grouping commas
    str = str.replace(/[\s  ]/g, "").replace(/,/g, "");
    const m = str.match(/-?\d+(?:\.\d+)?/);
    if (!m) return undefined;
    const n = parseFloat(m[0]);
    return isNaN(n) ? undefined : n;
  }

  // Header text → trade field. Duplicate "Time"/"Price" are resolved
  // positionally (1st = open, 2nd = close) via the running `counts` object.
  const STRUCT_HEADER_MAP = {
    ticket: "ticket", order: "ticket", deal: "ticket", id: "ticket", position: "ticket",
    type: "type", direction: "type", side: "type",
    volume: "volume", lots: "volume", size: "volume", "lot": "volume",
    symbol: "symbol", instrument: "symbol", asset: "symbol",
    "s/l": "sl", "s / l": "sl", sl: "sl", "stop loss": "sl", "stoploss": "sl",
    "t/p": "tp", "t / p": "tp", tp: "tp", "take profit": "tp", "takeprofit": "tp",
    commission: "commission", comm: "commission",
    fee: "fee", fees: "fee",
    swap: "swap", rollover: "swap",
    profit: "profit", "net profit": "profit", pnl: "profit", "p/l": "profit", "p / l": "profit", result: "profit",
    comment: "comment", note: "comment", reason: "comment",
  };

  function headerToField(headerText, counts) {
    // Strip trailing ellipsis — CSS text-overflow may cause browsers to report
    // "Commission" as "Comm…" via innerText on narrow columns
    const h = headerText.toLowerCase().trim().replace(/\s+/g, " ").replace(/[…\.]+$/, '');
    if (!h) return null;

    // ── Time columns ── (positional: 1st → openTime, 2nd → closeTime)
    if (h === "time" || h === "open time"  || h === "close time" ||
        h === "open date" || h === "close date" || h === "date" ||
        h === "time_open" || h === "time_close" ||     // Svelte data-field names
        h === "open_time" || h === "close_time") {
      if (/open/.test(h)) return "openTime";
      if (/close/.test(h)) return "closeTime";
      counts.time = (counts.time || 0) + 1;
      return counts.time === 1 ? "openTime" : "closeTime";
    }

    // ── Price columns ── (positional: 1st → openPrice, 2nd → closePrice)
    if (h === "price" || h === "open price"  || h === "close price" ||
        h === "entry price" || h === "exit price" ||
        h === "price_open" || h === "price_close" ||   // Svelte data-field names
        h === "open_price" || h === "close_price") {
      if (/open|entry/.test(h)) return "openPrice";
      if (/close|exit/.test(h)) return "closePrice";
      counts.price = (counts.price || 0) + 1;
      return counts.price === 1 ? "openPrice" : "closePrice";
    }

    const direct = STRUCT_HEADER_MAP[h];
    if (direct) return direct;

    // ── Prefix fallback for narrow/truncated column headers ──────────────────
    // e.g. "Comm" or "Comm…" → commission ; "F" → fee ; "Sw"/"S" → swap
    if (h.startsWith('comm')) return 'commission';
    if (h === 'f') return 'fee';
    if (h === 's' || h === 'sw') return 'swap';

    return null;
  }

  // Fields that must be parsed as numbers.
  const NUMERIC_FIELDS = new Set([
    "volume", "openPrice", "closePrice", "sl", "tp",
    "commission", "fee", "swap", "profit",
  ]);

  function buildTradeFromCells(fields, cells) {
    const trade = {};
    const n = Math.min(fields.length, cells.length);
    for (let i = 0; i < n; i++) {
      const field = fields[i];
      if (!field) continue;
      const raw = (cells[i] == null ? "" : String(cells[i])).trim();
      if (raw === "") continue; // preserve "blank" → leave field unset
      if (NUMERIC_FIELDS.has(field)) {
        const v = cleanNumber(raw);
        if (v !== undefined) trade[field] = v;
      } else if (field === "type") {
        trade.type = raw.toLowerCase();
      } else if (field === "symbol") {
        trade.symbol = raw.toUpperCase();
      } else {
        trade[field] = raw;
      }
    }
    return trade;
  }

  // Get a row's cells preserving EMPTY cells (one entry per column).
  function getRowCells(row) {
    // Prefer real grid/table cells so empty columns keep their slot.
    let cellEls = row.querySelectorAll(
      ':scope > td, :scope > th, :scope > [role="gridcell"], :scope > [role="cell"], :scope > .ag-cell'
    );
    if (cellEls.length === 0) {
      cellEls = row.querySelectorAll('td, th, [role="gridcell"], [role="cell"], .ag-cell');
    }
    if (cellEls.length === 0) return null;
    // If ag-grid exposes column indices, order by them for safety.
    const arr = Array.from(cellEls);
    const haveColIdx = arr.every((c) => c.getAttribute && c.getAttribute("aria-colindex"));
    if (haveColIdx) {
      arr.sort(
        (a, b) =>
          parseInt(a.getAttribute("aria-colindex")) -
          parseInt(b.getAttribute("aria-colindex"))
      );
    }
    return arr.map((c) => (c.innerText || c.textContent || "").trim());
  }

  function getHeaderTexts(container) {
    let headerEls = container.querySelectorAll(
      'thead th, thead td, [role="columnheader"], .ag-header-cell'
    );
    if (headerEls.length === 0) {
      const firstRow = container.querySelector("tr");
      if (firstRow) headerEls = firstRow.querySelectorAll("th, td");
    }
    const arr = Array.from(headerEls);
    // Sort by aria-colindex so pinned + center header cells are in the correct
    // column order even when they come from different DOM containers.
    const haveColIdx = arr.length > 0 && arr.every(h => h.getAttribute && h.getAttribute('aria-colindex'));
    if (haveColIdx) {
      arr.sort((a, b) => parseInt(a.getAttribute('aria-colindex')) - parseInt(b.getAttribute('aria-colindex')));
    }
    return arr.map((h) => {
      const t = h.querySelector(".ag-header-cell-text");
      return ((t ? t.innerText : h.innerText) || h.textContent || "").trim();
    });
  }

  // ─── Strategy -1: Column-position-aware structured extractor ─────────────
  function tryExtractStructured() {
    const trades = [];

    // Candidate containers: real tables, ARIA grids, ag-grid roots.
    const containers = [
      ...document.querySelectorAll("table"),
      ...document.querySelectorAll('[role="grid"], [role="table"]'),
      ...document.querySelectorAll(".ag-root, .ag-root-wrapper"),
    ];

    for (const container of containers) {
      // AG Grid containers are handled by tryExtractFromAgGrid() which properly
      // merges split-viewport rows. Skip ANY container that is an AG Grid root
      // or that contains AG Grid cells/rows as descendants — reading partial
      // viewport fragments here produces wrong column alignment.
      if (
        container.classList.contains('ag-root') ||
        container.classList.contains('ag-root-wrapper') ||
        container.querySelector('.ag-cell, .ag-row')
      ) continue;

      const headerTexts = getHeaderTexts(container);
      if (headerTexts.length < 4) continue;

      // Map headers → fields (duplicate-aware).
      const counts = {};
      const fields = headerTexts.map((h) => headerToField(h, counts));

      // Confirm this looks like a trade table.
      const hasTicket = fields.includes("ticket");
      const hasProfit = fields.includes("profit");
      const hasType = fields.includes("type");
      if (!(hasTicket && (hasProfit || hasType))) continue;

      // Data rows (exclude header rows).
      let rowEls = container.querySelectorAll(
        'tbody tr, [role="row"], .ag-row:not(.ag-row-empty)'
      );
      if (rowEls.length === 0) {
        rowEls = container.querySelectorAll("tr");
      }

      const containerTrades = [];
      let attemptedRows = 0;
      for (const row of rowEls) {
        if (row.querySelector("th") && !row.querySelector("td")) continue; // header row
        if (row.closest("thead, .ag-header")) continue;
        const cells = getRowCells(row);
        if (!cells || cells.length < 4) continue;
        attemptedRows++;

        const trade = buildTradeFromCells(fields, cells);
        // Require at least a ticket or a timestamp + a money value.
        if (!trade.ticket && !trade.openTime) continue;
        if (trade.profit === undefined && trade.closePrice === undefined && !trade.openPrice) continue;
        containerTrades.push(trade);
      }

      // Quality gate: a correctly-read trade table has most rows carrying BOTH a
      // ticket and a profit. AG-Grid splits a logical row across pinned/center
      // viewports, producing partial rows — reject those and let a later
      // strategy handle it instead of emitting corrupt half-rows.
      const complete = containerTrades.filter(
        (t) => t.ticket && t.profit !== undefined
      ).length;
      const enough =
        containerTrades.length >= 1 &&
        complete >= Math.max(1, Math.floor(containerTrades.length * 0.5));

      if (enough) {
        for (const t of containerTrades) trades.push(t);
        return trades; // first confident container wins
      }
    }

    return trades;
  }

  // ─── Strategy 0: AG Grid ───────────────────────────────────────────────
  // MT5 Web Terminal column layout (confirmed):
  //   1:Time  2:Ticket  3:Type  4:Volume  5:Symbol  6:Price  7:S/L  8:T/P
  //   9:Time  10:Price  11:Commission  12:Fee  13:Swap  14:Profit
  //
  // AG Grid splits a logical row across pinned-left + center viewport containers.
  // We use a Map<aria-colindex → field> so blank cells (truly empty, no "0.000")
  // stay absent from the trade object — they cannot shift commission into closePrice.
  function tryExtractFromAgGrid() {
    const trades = [];
    const grids = document.querySelectorAll(".ag-root, .ag-root-wrapper");
    if (grids.length === 0) return trades;

    for (const grid of grids) {
      // ── Step 1: build colIndex → field map from header cells ──────────────
      // Sort by aria-colindex so duplicate "Time"/"Price" counters fire in the
      // correct left-to-right order (1st Time → openTime, 2nd → closeTime, etc.)
      const rawHeaderCells = Array.from(
        grid.querySelectorAll(".ag-header-row:not(.ag-header-row-column-filter) .ag-header-cell")
      );
      rawHeaderCells.sort((a, b) =>
        parseInt(a.getAttribute('aria-colindex') || '0') -
        parseInt(b.getAttribute('aria-colindex') || '0')
      );

      const colIdxToField = new Map(); // colIndex (1-based) → field name
      const counts = {};
      for (const hCell of rawHeaderCells) {
        const colIdx = parseInt(hCell.getAttribute('aria-colindex') || '0');
        if (colIdx === 0) continue;
        const textNode = hCell.querySelector('.ag-header-cell-text');
        const headerText = (textNode ? textNode.innerText : hCell.innerText || hCell.textContent || '').trim();
        if (!headerText) continue;
        const field = headerToField(headerText, counts);
        if (field) colIdxToField.set(colIdx, field);
      }

      if (colIdxToField.size < 4) continue;

      // Confirm this is a trade table
      const allFields = Array.from(colIdxToField.values());
      if (!allFields.includes('ticket') && !allFields.includes('openTime')) continue;
      if (!allFields.includes('profit') && !allFields.includes('type')) continue;

      // ── Step 2: group row fragments by aria-rowindex ──────────────────────
      const rowMap = new Map();
      for (const row of grid.querySelectorAll('.ag-row:not(.ag-row-empty)')) {
        if (row.closest('.ag-header')) continue;
        const rowIdx = row.getAttribute('aria-rowindex');
        if (!rowIdx) continue;
        if (!rowMap.has(rowIdx)) rowMap.set(rowIdx, []);
        rowMap.get(rowIdx).push(row);
      }

      // ── Step 3: build trade from merged fragments ─────────────────────────
      for (const rowEls of rowMap.values()) {
        // Collect colIndex → cell text across ALL viewport fragments for this row
        const colIdxToText = new Map();
        for (const rowEl of rowEls) {
          for (const cell of rowEl.querySelectorAll('.ag-cell')) {
            const colIdx = parseInt(cell.getAttribute('aria-colindex') || '0');
            if (colIdx > 0 && !colIdxToText.has(colIdx)) {
              colIdxToText.set(colIdx, (cell.innerText || cell.textContent || '').trim());
            }
          }
        }

        if (colIdxToText.size < 3) continue;

        // Map each column's text to its trade field
        const trade = {};
        for (const [colIdx, field] of colIdxToField.entries()) {
          const raw = colIdxToText.get(colIdx);
          if (raw == null || raw === '') continue; // blank cell → field absent (not 0!)
          if (NUMERIC_FIELDS.has(field)) {
            const v = cleanNumber(raw);
            if (v !== undefined) trade[field] = v;
          } else if (field === 'type') {
            trade.type = raw.toLowerCase();
          } else if (field === 'symbol') {
            trade.symbol = raw.replace(/\.$/, '').toUpperCase(); // strip trailing dot
          } else {
            trade[field] = raw;
          }
        }

        if (trade.ticket || trade.openTime) trades.push(trade);
      }
    }
    return trades;
  }

  // ─── Strategy S: Svelte div-table extractor ──────────────────────────────
  // The MT5 Web Terminal at mt5.the5ers.com (and similar Svelte-based brokers)
  // renders trade history into a custom div-table:
  //
  //   <div class="table svelte-xxx">
  //     <div class="thead svelte-xxx">
  //       <div class="tr svelte-xxx">
  //         <div class="th svelte-xxx">Time</div>      ← column 0  → openTime
  //         <div class="th svelte-xxx">Ticket</div>    ← column 1  → ticket
  //         ...14 columns total...
  //       </div>
  //     </div>
  //     <div class="tbody svelte-xxx">
  //       <div class="tr svelte-xxx">                   ← data row
  //         <div class="td svelte-xxx">2026.05.18...</div>
  //         ...
  //       </div>
  //     </div>
  //   </div>
  //
  // Confirmed 14-column layout:
  //   openTime | ticket | type | volume | symbol | openPrice |
  //   sl | tp | closeTime | closePrice | commission | fee | swap | profit
  //
  // Because Svelte renders ALL rows into the DOM at once (no virtual scrolling),
  // a single querySelectorAll gives us the complete history — no scroll needed.
  function tryExtractFromSvelteTable() {
    // Confirmed 14-column fixed layout (MT5 the5ers.com terminal)
    const SVELTE_FIXED_FIELDS = [
      'openTime', 'ticket', 'type', 'volume', 'symbol', 'openPrice',
      'sl', 'tp', 'closeTime', 'closePrice', 'commission', 'fee', 'swap', 'profit',
    ];
    // Header keywords used to skip header rows during content scan
    const HEADER_KW = /^(time|date|ticket|order|deal|type|direction|volume|lots|size|symbol|instrument|price|s\/l|sl|t\/p|tp|commission|comm|fee|swap|profit|pnl|p\/l)$/i;
    const TS_RE   = /\d{4}[.\/-]\d{2}[.\/-]\d{2}\s+\d{2}:\d{2}/;  // MT5 timestamp
    // Use word-boundary variants so cells that have a trailing dot / icon /
    // non-breaking space still match (e.g. "buy " or "553047088." from Svelte).
    const TYPE_RE = /\b(buy|sell)\b/i;
    const TKT_RE  = /\b\d{7,10}\b/;

    // ── Helper: read cells from a row element and build a trade ────────────
    const rowToTrade = (row, fields) => {
      const texts = Array.from(row.children).map(c => (c.innerText || c.textContent || '').trim());
      if (texts.length < 4) return null;
      const t = buildTradeFromCells(fields, texts);
      return (t.ticket || t.openTime) ? t : null;
    };

    // ── Helper: extract column headers from a candidate header element ─────
    const extractFields = (headerEl) => {
      const texts = Array.from(headerEl.children).map(c => (c.innerText || c.textContent || '').trim());
      if (texts.length < 4) return null;
      const counts = {};
      const mapped = texts.map(h => headerToField(h, counts));
      return mapped.filter(f => f != null).length >= 4 ? mapped : null;
    };

    // ════════════════════════════════════════════════════════════════════════
    // STRATEGY A — CSS class-based (Svelte: .tbody / .tr / .td / .th)
    // Works when the Svelte component uses these semantic class names.
    // ════════════════════════════════════════════════════════════════════════
    const tryCssStrategy = () => {
      const containers = new Set();

      // A-1: any element whose .tbody child's parent also has ≥4 .th elements
      for (const tbody of document.querySelectorAll('.tbody')) {
        const p = tbody.parentElement;
        if (p && p.querySelectorAll('.th').length >= 4) containers.add(p);
      }

      // A-2: walk up from any .th with trade-keyword text
      if (containers.size === 0) {
        for (const th of document.querySelectorAll('.th')) {
          const t = (th.innerText || th.textContent || '').trim().toLowerCase();
          if (t === 'ticket' || t === 'profit' || t === 'type') {
            let el = th.parentElement;
            while (el && el !== document.body) {
              if (el.querySelectorAll('.tr').length >= 2 &&
                  el.querySelectorAll('.th').length >= 4) {
                containers.add(el);
                break;
              }
              el = el.parentElement;
            }
          }
        }
      }

      for (const container of containers) {
        // Determine field mapping from header row
        let fields = SVELTE_FIXED_FIELDS;
        let headerTexts = [];

        for (const row of container.querySelectorAll('.tr')) {
          const ths = row.querySelectorAll('.th');
          if (ths.length >= 4) {
            headerTexts = Array.from(ths).map(h => (h.innerText || h.textContent || '').trim());
            break;
          }
        }
        if (headerTexts.length < 4) {
          const all = container.querySelectorAll('.thead .th, .th');
          if (all.length >= 4)
            headerTexts = Array.from(all).map(h => (h.innerText || h.textContent || '').trim());
        }
        if (headerTexts.length >= 4) {
          const counts = {};
          const mapped = headerTexts.map(h => headerToField(h, counts));
          if (mapped.filter(f => f != null).length >= 4) fields = mapped;
          else if (headerTexts.length >= 10) fields = SVELTE_FIXED_FIELDS.slice(0, headerTexts.length);
        }

        if (!fields.includes('ticket') || !fields.includes('profit')) continue;

        const result = [];
        for (const row of container.querySelectorAll('.tr')) {
          if (row.querySelector('.th')) continue;
          const cells = row.querySelectorAll('.td');
          if (cells.length < 4) continue;
          const texts = Array.from(cells).map(c => (c.innerText || c.textContent || '').trim());
          const t = buildTradeFromCells(fields, texts);
          if (t.ticket || t.openTime) result.push(t);
        }
        if (result.length > 0) return result;
      }
      return [];
    };

    // ════════════════════════════════════════════════════════════════════════
    // STRATEGY B — content-based (zero CSS class dependency)
    // Finds trade rows by their DATA: a row whose direct children include
    // an MT5 timestamp, a buy/sell type, and a 7-10 digit ticket number.
    // Works regardless of what class names the Svelte component uses.
    // ════════════════════════════════════════════════════════════════════════
    const tryContentStrategy = () => {
      // Walk all DOM elements looking for a leaf node that contains a ticket number.
      // Then walk UP to find the enclosing "row" element (the ancestor whose
      // direct children form the full set of trade columns).
      let sampleRow = null;

      for (const el of document.getElementsByTagName('*')) {
        if (el.children.length !== 0) continue;               // leaf only
        const text = (el.innerText || el.textContent || '').trim();
        if (!TKT_RE.test(text)) continue;

        // Walk up up to 5 levels looking for a row element
        let candidate = el.parentElement;
        for (let lvl = 0; lvl < 5 && candidate && candidate !== document.body; lvl++) {
          const childTexts = Array.from(candidate.children)
            .map(c => (c.innerText || c.textContent || '').trim());

          if (candidate.children.length >= 8 &&
              childTexts.some(t => TYPE_RE.test(t)) &&
              childTexts.some(t => TS_RE.test(t))  &&
              childTexts.some(t => TKT_RE.test(t))) {
            sampleRow = candidate;
            break;
          }
          candidate = candidate.parentElement;
        }
        if (sampleRow) break;
      }

      if (!sampleRow) return [];

      // The immediate parent is the container holding all trade rows
      const container = sampleRow.parentElement;
      if (!container) return [];

      // Determine field order: try to find a header sibling first
      let fields = SVELTE_FIXED_FIELDS.slice(0, sampleRow.children.length);
      for (const sibling of container.children) {
        if (sibling === sampleRow) continue;
        const childTexts = Array.from(sibling.children).map(c => (c.innerText || c.textContent || '').trim());
        // A header row has ≥3 header-keyword cells and NO timestamp
        if (childTexts.filter(t => HEADER_KW.test(t)).length >= 3 &&
            !childTexts.some(t => TS_RE.test(t))) {
          const f = extractFields(sibling);
          if (f) { fields = f; break; }
        }
      }

      const result = [];
      for (const child of container.children) {
        const childTexts = Array.from(child.children)
          .map(c => (c.innerText || c.textContent || '').trim());
        if (childTexts.length < 4) continue;

        // Skip header rows (≥3 header keywords, no timestamp)
        if (childTexts.filter(t => HEADER_KW.test(t)).length >= 3 &&
            !childTexts.some(t => TS_RE.test(t))) continue;

        // Must look like a trade row (has timestamp or ticket)
        if (!childTexts.some(t => TS_RE.test(t)) && !childTexts.some(t => TKT_RE.test(t))) continue;

        const trade = buildTradeFromCells(fields, childTexts);
        if (trade.ticket || trade.openTime) result.push(trade);
      }
      return result;
    };

    // ── Run strategies in order; first success wins ──────────────────────
    const cssResult = tryCssStrategy();
    if (cssResult.length > 0) return cssResult;

    const contentResult = tryContentStrategy();
    if (contentResult.length > 0) return contentResult;

    return [];
  }

  // ─── Strategy 1: MT5 official web terminal selectors ───────────────────
  function tryExtractFromWebTerminal() {
    const trades = [];

    // MT5 web uses various class names — we try the most common ones
    const rowSelectors = [
      "tr.terminal-history-row",
      "tr[data-id]",
      ".wt-deal",
      ".history-row",
      "tr.tr-trade",
      ".trade-row",
      "[class*='history'] tr",
      "[class*='deals'] tr",
      "[class*='terminal'] tbody tr",
    ];

    let rows = [];
    for (const sel of rowSelectors) {
      const found = document.querySelectorAll(sel);
      if (found.length > 0) {
        rows = Array.from(found);
        break;
      }
    }

    for (const row of rows) {
      const cells = Array.from(row.querySelectorAll("td, .cell, [class*='cell']"));
      if (cells.length < 3) continue;

      const text = cells.map((c) => c.innerText.trim());
      const trade = parseCellsToTrade(text);
      if (trade) trades.push(trade);
    }

    return trades;
  }

  // ─── Strategy 2: Any HTML table that looks like trades ─────────────────
  function tryExtractFromGenericTable() {
    const trades = [];
    const tables = document.querySelectorAll("table");

    for (const table of tables) {
      const headers = Array.from(
        table.querySelectorAll("thead th, thead td, tr:first-child th, tr:first-child td")
      ).map((h) => h.innerText.trim().toLowerCase());

      // Check if this looks like a trade table
      const tradeKeywords = ["ticket", "time", "type", "symbol", "price", "profit", "volume", "lot"];
      const matches = tradeKeywords.filter((k) => headers.some((h) => h.includes(k)));
      if (matches.length < 2) continue;

      const bodyRows = table.querySelectorAll("tbody tr, tr:not(:first-child)");
      for (const row of bodyRows) {
        const cells = Array.from(row.querySelectorAll("td")).map((c) => c.innerText.trim());
        if (cells.length < 3) continue;
        const trade = mapByHeaders(headers, cells);
        if (trade) trades.push(trade);
      }
    }

    return trades;
  }

  // ─── Strategy 3: Parse visible text blocks ─────────────────────────────
  function tryExtractFromVisibleText() {
    const trades = [];

    // Look for elements that contain trade-like data patterns
    // Pattern: timestamp + ticket + buy/sell + volume + symbol + price
    const allText = document.body.innerText;
    const lines = allText.split("\n").map((l) => l.trim()).filter((l) => l.length > 5);

    // Find lines that look like trade rows
    // e.g. "2026.05.29 15:52:19  7231260  buy  0.05  XAUUSD.  4520.180  4512.656  4531.649"
    const tradePattern =
      /(\d{4}\.\d{2}\.\d{2}\s+\d{2}:\d{2}:\d{2})\s+(\d{5,})\s+(buy|sell|balance)\s+([\d.]+)?\s*([A-Z]{2,}[.\w]*)?/i;

    for (const line of lines) {
      const match = line.match(tradePattern);
      if (match) {
        const parts = line.split(/\s{2,}|\t/).filter((p) => p.trim());
        const trade = parseCellsToTrade(parts);
        if (trade) trades.push(trade);
      }
    }

    return trades;
  }

  // ─── Cell → Trade object mapper ────────────────────────────────────────
  // ─── Strategy 1: Heuristic DOM Row Scraper (Super robust) ─────────────
  function tryExtractFromHeuristicDOM() {
    const trades = [];
    const ticketRegex = /\b\d{7,10}\b/;
    const typeRegex = /\b(buy|sell|balance|deposit|credit)\b/i;

    const allElements = document.getElementsByTagName("*");
    const candidateRows = new Set();

    for (let i = 0; i < allElements.length; i++) {
      const el = allElements[i];
      if (el.children.length === 0) {
        const text = el.innerText ? el.innerText.trim() : "";
        if (ticketRegex.test(text)) {
          let parent = el.parentElement;
          let level = 0;
          let bestRow = null;
          while (parent && level < 4) {
            const parentText = parent.innerText || "";
            // If the parent wraps multiple tickets, we stop going up to prevent cross-row contamination
            const tickets = parentText.match(/\b\d{6,10}\b/g);
            if (tickets && tickets.length > 1) {
              break;
            }
            if (typeRegex.test(parentText)) {
              bestRow = parent;
            }
            parent = parent.parentElement;
            level++;
          }
          if (bestRow) {
            candidateRows.add(bestRow);
          }
        }
      }
    }

    candidateRows.forEach((row) => {
      const cellTexts = [];
      const walk = document.createTreeWalker(row, NodeFilter.SHOW_TEXT, null, false);
      let node;
      while (node = walk.nextNode()) {
        const val = node.nodeValue.trim();
        if (val.length > 0) {
          cellTexts.push(val);
        }
      }

      if (cellTexts.length >= 3) {
        const trade = parseCellsToTrade(cellTexts);
        if (trade) {
          trades.push(trade);
        }
      }
    });

    return trades;
  }

  // ─── Cell → Trade object mapper ────────────────────────────────────────
  function parseCellsToTrade(cells) {
    if (!cells || cells.length < 3) return null;

    const trade = {};
    const timestamps = [];
    let closeTimeCellIdx = -1;
    
    // 1. Find timestamps and their indices
    for (let i = 0; i < cells.length; i++) {
      const c = cells[i];
      if (/\d{4}[.\-\/]\d{2}[.\-\/]\d{2}/.test(c) || /\d{2}[.\-\/]\d{2}[.\-\/]\d{2,4}/.test(c)) {
        let ts = c;
        let consumedNext = false;
        if (i + 1 < cells.length && /^\d{2}:\d{2}(:\d{2})?$/.test(cells[i + 1])) {
          ts += " " + cells[i + 1];
          consumedNext = true;
        }
        timestamps.push(ts);
        if (timestamps.length === 1) trade.openTime = ts;
        if (timestamps.length === 2) {
          trade.closeTime = ts;
          closeTimeCellIdx = consumedNext ? i + 1 : i;
        }
        if (consumedNext) i++;
      }
    }

    // 2. Ticket
    const ticketIdx = cells.findIndex((c) => /^\d{6,}$/.test(c.replace(/\s/g, "")));
    if (ticketIdx >= 0) trade.ticket = cells[ticketIdx].replace(/\s/g, "");

    // 3. Type
    const typeIdx = cells.findIndex((c) => /^(buy|sell|balance|deposit|credit)$/i.test(c.trim()));
    if (typeIdx >= 0) trade.type = cells[typeIdx].toLowerCase().trim();

    // 4. Symbol
    const symbolIdx = cells.findIndex((c) => {
      const val = c.trim().toUpperCase();
      return /^[A-Z]{2,6}([A-Z0-9_+#.]{1,6})?$/.test(val) && val.length >= 3 && !/^(BUY|SELL|BALANCE|DEPOSIT|CREDIT)$/.test(val);
    });
    if (symbolIdx >= 0) trade.symbol = cells[symbolIdx].trim().toUpperCase();

    // Helper to extract numbers from a slice of cells
    const getNumbers = (start, end) => {
      const nums = [];
      for(let i = start; i <= end; i++) {
        if (cells[i] === undefined || cells[i] === null) continue;
        if (i === ticketIdx) continue;
        if (timestamps.some(ts => ts.includes(cells[i]))) continue;
        if (symbolIdx === i) continue;
        if (typeIdx === i) continue;
        
        const val = parseFloat(cells[i].replace(/\s/g, "").replace(",", "."));
        if (!isNaN(val)) nums.push(val);
      }
      return nums;
    };

    // 5. Split numbers into before and after close time
    let headNumbers = [];
    let tailNumbers = [];

    if (closeTimeCellIdx !== -1) {
      headNumbers = getNumbers(0, closeTimeCellIdx - 1);
      tailNumbers = getNumbers(closeTimeCellIdx + 1, cells.length - 1);
    } else {
      headNumbers = getNumbers(0, cells.length - 1);
    }

    // Process head numbers: Volume, OpenPrice, [SL], [TP]
    if (headNumbers.length > 0) trade.volume = headNumbers[0];
    if (headNumbers.length > 1) trade.openPrice = headNumbers[1];
    
    // If we have 4 head numbers, it's definitely SL and TP
    if (headNumbers.length >= 4) {
      trade.sl = headNumbers[2];
      trade.tp = headNumbers[3];
    } 
    // If we have 3, we don't know if it's SL or TP, default to SL (most common to have SL only)
    else if (headNumbers.length === 3) {
      trade.sl = headNumbers[2];
    }

    // Process tail numbers: ClosePrice, [Commission], [Fee], [Swap], Profit
    if (tailNumbers.length > 0) {
      trade.closePrice = tailNumbers[0];
      
      if (tailNumbers.length >= 2) {
        trade.profit = tailNumbers[tailNumbers.length - 1];
      }
      
      const middleCount = tailNumbers.length - 2;
      if (middleCount === 1) {
        trade.commission = tailNumbers[1];
      } else if (middleCount === 2) {
        trade.commission = tailNumbers[1];
        trade.swap = tailNumbers[2]; // usually fee is empty, swap is present
      } else if (middleCount >= 3) {
        trade.commission = tailNumbers[1];
        trade.fee = tailNumbers[2];
        trade.swap = tailNumbers[3];
      }
    } else if (closeTimeCellIdx === -1 && headNumbers.length > 2) {
        // Active trade, no close time. Last number is profit.
        trade.profit = headNumbers[headNumbers.length - 1];
    }

    // Comment
    const lastCell = cells[cells.length - 1];
    if (lastCell && isNaN(parseFloat(lastCell)) && lastCell.length > 0 && symbolIdx !== cells.length - 1) {
      trade.comment = lastCell.trim();
    }

    if (!trade.ticket && !trade.openTime) return null;
    return trade;
  }

  // ─── Map table cells to trade using header names ────────────────────────
  function mapByHeaders(headers, cells) {
    if (headers.length === 0 || cells.length === 0) return null;

    const trade = {};
    const headerMap = {
      time: "openTime",
      "open time": "openTime",
      "open date": "openTime",
      ticket: "ticket",
      order: "ticket",
      deal: "ticket",
      id: "ticket",
      type: "type",
      direction: "type",
      volume: "volume",
      lots: "volume",
      size: "volume",
      symbol: "symbol",
      instrument: "symbol",
      asset: "symbol",
      price: "openPrice",
      "open price": "openPrice",
      "entry price": "openPrice",
      "s/l": "sl",
      "s / l": "sl",
      sl: "sl",
      "stop loss": "sl",
      "t/p": "tp",
      "t / p": "tp",
      tp: "tp",
      "take profit": "tp",
      "close time": "closeTime",
      "exit time": "closeTime",
      "close price": "closePrice",
      "exit price": "closePrice",
      commission: "commission",
      fee: "fee",
      swap: "swap",
      profit: "profit",
      "net profit": "profit",
      pnl: "profit",
      comment: "comment",
      note: "comment",
    };

    let timeCount = 0;
    let priceCount = 0;

    for (let i = 0; i < Math.min(headers.length, cells.length); i++) {
      let h = headers[i].toLowerCase().trim().replace(/\s+/g, ' ');
      let key = headerMap[h] || h;

      if (h === "time") {
        timeCount++;
        if (timeCount === 1) key = "openTime";
        else if (timeCount === 2) key = "closeTime";
      }
      if (h === "price") {
        priceCount++;
        if (priceCount === 1) key = "openPrice";
        else if (priceCount === 2) key = "closePrice";
      }

      if (cells[i] !== undefined && cells[i] !== "") {
        if (NUMERIC_FIELDS.has(key)) {
          const v = cleanNumber(cells[i]);
          if (v !== undefined) trade[key] = v;
        } else if (key === "type") {
          trade.type = String(cells[i]).toLowerCase().trim();
        } else if (key === "symbol") {
          trade.symbol = String(cells[i]).toUpperCase().trim();
        } else {
          trade[key] = cells[i];
        }
      }
    }

    return Object.keys(trade).length > 0 ? trade : null;
  }
})();
