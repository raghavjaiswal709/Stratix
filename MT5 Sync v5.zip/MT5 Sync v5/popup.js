// MT5 Trade Extractor - Popup Logic
"use strict";

// ─── State ────────────────────────────────────────────────────────────────
let currentTrades = [];      // trades from current scan
let storedTrades = [];       // previously extracted trades (from storage)
let selectedKeys = new Set(); // keys (ticket_openTime) of currently selected trades

// ─── DOM refs ─────────────────────────────────────────────────────────────
const statusDot    = document.getElementById("statusDot");
const totalFound   = document.getElementById("totalFound");
const totalSelected= document.getElementById("totalSelected");
const totalStored  = document.getElementById("totalStored");
const tradeCount   = document.getElementById("tradeCount");
const historicalOption = document.getElementById("historicalOption");
const btnScan      = document.getElementById("btnScan");
const scanSpinner  = document.getElementById("scanSpinner");
const scanLabel    = document.getElementById("scanLabel");
const btnCopyCsv   = document.getElementById("btnCopyCsv");
const btnCopyJson  = document.getElementById("btnCopyJson");
const btnClear     = document.getElementById("btnClear");
const previewWrap  = document.getElementById("previewWrap");
const alertBox     = document.getElementById("alertBox");
const footerCount  = document.getElementById("footerCount");
const newBadge     = document.getElementById("newBadge");

// ─── Init ──────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  await loadStoredTrades();
  updateStoredStats();
  pingActiveTab();
  
  // Load saved preferences
  chrome.storage.local.get(["mt5_trade_count", "mt5_historical_only"], (result) => {
    if (result.mt5_trade_count !== undefined) {
      tradeCount.value = result.mt5_trade_count;
    }
    let isHist = false;
    if (result.mt5_historical_only !== undefined) {
      historicalOption.checked = result.mt5_historical_only;
      isHist = result.mt5_historical_only;
    } else {
      historicalOption.checked = false; // default
    }

    // Only display storedTrades on startup if historical option is ON
    if (isHist && storedTrades.length > 0) {
      currentTrades = [...storedTrades];
      totalFound.textContent = storedTrades.length;
      const count = tradeCount.value ? parseInt(tradeCount.value) : null;
      const displayTrades = count ? getSlicedTrades(storedTrades, count) : storedTrades;
      totalSelected.textContent = displayTrades.length;
      renderPreview(displayTrades);
      btnCopyCsv.disabled = false;
      btnCopyJson.disabled = false;
    } else {
      totalFound.textContent = "0";
      totalSelected.textContent = "0";
      renderPreview([]);
      btnCopyCsv.disabled = true;
      btnCopyJson.disabled = true;
    }
  });

  // Save preferences on change
  tradeCount.addEventListener("change", () => {
    chrome.storage.local.set({ mt5_trade_count: tradeCount.value });
  });
  historicalOption.addEventListener("change", () => {
    chrome.storage.local.set({ mt5_historical_only: historicalOption.checked });
    
    // Switch display/preview on toggle
    const historical = historicalOption.checked;
    const sourceList = historical ? storedTrades : currentTrades;
    totalFound.textContent = sourceList.length;
    
    const count = tradeCount.value ? parseInt(tradeCount.value) : null;
    const displayTrades = count ? getSlicedTrades(sourceList, count) : sourceList;
    totalSelected.textContent = displayTrades.length;
    renderPreview(displayTrades);
    
    const noneSelected = displayTrades.length === 0;
    btnCopyCsv.disabled = noneSelected;
    btnCopyJson.disabled = noneSelected;
  });
});

// ─── Load stored trades from chrome.storage ───────────────────────────────
async function loadStoredTrades() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["mt5_stored_trades"], (result) => {
      storedTrades = sortTradesNewestFirst((result.mt5_stored_trades || []).filter(isActualTrade));
      resolve();
    });
  });
}

// ─── Save current trades to storage ──────────────────────────────────────
function saveToStorage(trades) {
  // Merge, deduplicate by ticket+openTime
  const merged = [...storedTrades];
  for (const t of trades) {
    if (!isActualTrade(t)) continue;
    const key = `${t.ticket}_${t.openTime}`;
    const exists = merged.some((s) => `${s.ticket}_${s.openTime}` === key);
    if (!exists) merged.push(t);
  }
  storedTrades = sortTradesNewestFirst(merged);
  chrome.storage.local.set({ mt5_stored_trades: storedTrades });
  return merged.length - (storedTrades.length - trades.filter(t => {
    if (!isActualTrade(t)) return false;
    const key = `${t.ticket}_${t.openTime}`;
    return !storedTrades.some((s) => `${s.ticket}_${s.openTime}` === key);
  }).length);
}

// ─── Ping active tab for content script ───────────────────────────────────
async function pingActiveTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;

    await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      files: ["content.js"],
    }).catch(() => {});

    chrome.tabs.sendMessage(tab.id, { action: "ping" }, (resp) => {
      if (chrome.runtime.lastError || !resp) {
        statusDot.className = "status-dot error";
        statusDot.title = "Content script not loaded on this page";
      } else {
        statusDot.className = "status-dot connected";
        statusDot.title = "Connected to page";
      }
    });
  } catch (e) {
    statusDot.className = "status-dot error";
  }
}

// ─── Scan button ──────────────────────────────────────────────────────────
btnScan.addEventListener("click", async () => {
  setBusy(true);
  showAlert("", "");

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) throw new Error("No active tab found");

    // Re-inject content script just in case
    await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      files: ["content.js"],
    }).catch(() => {});

    const count = tradeCount.value ? parseInt(tradeCount.value) : null;

    // Set up a temporary listener to collect trades from all frames
    let gatheredTrades = [];
    const collectedTickets = new Set();
    
    let framesAcked = 0;
    let framesFinished = 0;
    
    let resolveScan;
    const scanPromise = new Promise(r => { resolveScan = r; });
    
    // Absolute maximum wait time
    let scanTimeout = setTimeout(() => resolveScan(), 120000);

    function tempMessageListener(msg) {
      if (!msg) return;
      if (msg.action === "extractAck") {
        framesAcked++;
      } else if (msg.action === "tradesExtracted") {
        if (Array.isArray(msg.trades)) {
          for (const t of msg.trades) {
            const key = `${t.ticket}_${t.openTime}`;
            if (!collectedTickets.has(key)) {
              collectedTickets.add(key);
              gatheredTrades.push(t);
            }
          }
          if (scanLabel) {
            scanLabel.textContent = `Scanning (${gatheredTrades.length} found)…`;
          }
        }
        if (msg.isFinal) {
          framesFinished++;
          // If all acknowledged frames have reported back, we are done
          if (framesAcked > 0 && framesFinished >= framesAcked) {
            clearTimeout(scanTimeout);
            resolveScan();
          }
        }
      }
    }
    chrome.runtime.onMessage.addListener(tempMessageListener);

    const historical = historicalOption.checked;
    const autoScroll = true; // Always autoScroll to perform fast top-bottom scan if count is set
    const countToSend = count; // Send exact count to content script

    // Send the extraction command
    chrome.tabs.sendMessage(tab.id, { action: "extractTrades", count: countToSend, autoScroll, historical }, () => {
      // We ignore the standard callback and rely on the custom message flow.
      const err = chrome.runtime.lastError;
      
      // If no frames acknowledge within 1 second, assume no content scripts are active
      setTimeout(() => {
        if (framesAcked === 0) {
          clearTimeout(scanTimeout);
          resolveScan();
        }
      }, 1000);
    });

    await scanPromise;

    // Remove the listener
    chrome.runtime.onMessage.removeListener(tempMessageListener);

    currentTrades = sortTradesNewestFirst(gatheredTrades.filter(isActualTrade));

    if (currentTrades.length === 0) {
      if (historical) {
        showAlert(
          "No trades found on this page.\n\n" +
          "• Make sure the MT5 Web Terminal History tab is open and visible\n" +
          "• Try scrolling the history table into view first\n" +
          "• Some brokers use custom terminals — try the manual entry below",
          "warn"
        );
      } else {
        showAlert(
          "No trades found on this page.\n\n" +
          "• Make sure the MT5 Web Terminal Trade or History tab is open and visible\n" +
          "• Try scrolling the trade table into view first\n" +
          "• Some brokers use custom terminals — try the manual entry below",
          "warn"
        );
      }
      totalFound.textContent = "0";
      totalSelected.textContent = "0";
      renderPreview([]);
    } else {
      // Find new (not already stored)
      const newTrades = currentTrades.filter((t) => {
        const key = `${t.ticket}_${t.openTime}`;
        return !storedTrades.some((s) => `${s.ticket}_${s.openTime}` === key);
      });

      // Merge into storage
      const prevLen = storedTrades.length;
      const merged = [...storedTrades];
      for (const t of currentTrades) {
        const key = `${t.ticket}_${t.openTime}`;
        if (!merged.some((s) => `${s.ticket}_${s.openTime}` === key)) {
          merged.push(t);
        }
      }
      storedTrades = sortTradesNewestFirst(merged);
      chrome.storage.local.set({ mt5_stored_trades: storedTrades });

      const sourceList = historical ? storedTrades : currentTrades;

      totalFound.textContent = sourceList.length;
      const displayTrades = count ? getSlicedTrades(sourceList, count) : sourceList;
      totalSelected.textContent = displayTrades.length;
      updateStoredStats();

      if (newTrades.length > 0) {
        newBadge.style.display = "inline-flex";
        newBadge.textContent = `▲ ${newTrades.length} NEW`;
        showAlert(`✓ Extracted ${currentTrades.length} trade${currentTrades.length !== 1 ? "s" : ""} · ${newTrades.length} new since last scan`, "info");
      } else {
        newBadge.style.display = "none";
        showAlert(`✓ Extracted ${currentTrades.length} trade${currentTrades.length !== 1 ? "s" : ""} (no new trades since last scan)`, "info");
      }

      renderPreview(displayTrades);
      btnCopyCsv.disabled = false;
      btnCopyJson.disabled = false;
      btnClear.style.display = "";
      footerCount.textContent = `${displayTrades.length} trade${displayTrades.length !== 1 ? "s" : ""} ready`;
      statusDot.className = "status-dot connected";
    }
  } catch (err) {
    showAlert("Error: " + err.message, "error");
    statusDot.className = "status-dot error";
  }

  setBusy(false);
});

// ─── CSV Copy ─────────────────────────────────────────────────────────────
btnCopyCsv.addEventListener("click", () => {
  const historical = historicalOption.checked;
  const sourceList = historical ? storedTrades : currentTrades;
  if (!sourceList.length) return;
  const count = tradeCount.value ? parseInt(tradeCount.value) : null;
  const slicedTrades = count ? getSlicedTrades(sourceList, count) : sourceList;
  const trades = slicedTrades.filter(t => selectedKeys.has(`${t.ticket}_${t.openTime}`));
  if (!trades.length) return;
  const csv = tradesToCSV(trades);
  navigator.clipboard.writeText(csv).then(() => {
    showAlert("✓ CSV copied to clipboard!", "info");
  }).catch(err => {
    showAlert("Failed to copy: " + err, "error");
  });
});

// ─── JSON Copy ────────────────────────────────────────────────────────────
btnCopyJson.addEventListener("click", () => {
  const historical = historicalOption.checked;
  const sourceList = historical ? storedTrades : currentTrades;
  if (!sourceList.length) return;
  const count = tradeCount.value ? parseInt(tradeCount.value) : null;
  const slicedTrades = count ? getSlicedTrades(sourceList, count) : sourceList;
  const trades = slicedTrades.filter(t => selectedKeys.has(`${t.ticket}_${t.openTime}`));
  if (!trades.length) return;
  const json = JSON.stringify(
    {
      exportedAt: new Date().toISOString(),
      source: "MT5 Trade Extractor",
      totalTrades: trades.length,
      trades: trades,
    },
    null,
    2
  );
  navigator.clipboard.writeText(json).then(() => {
    showAlert("✓ JSON copied to clipboard!", "info");
  }).catch(err => {
    showAlert("Failed to copy: " + err, "error");
  });
});

// ─── Clear storage ────────────────────────────────────────────────────────
btnClear.addEventListener("click", () => {
  if (!confirm("Clear all stored trades? This cannot be undone.")) return;
  storedTrades = [];
  chrome.storage.local.remove("mt5_stored_trades");
  updateStoredStats();
  showAlert("Stored trades cleared.", "info");
  btnClear.style.display = "none";
});

// ─── Helpers ──────────────────────────────────────────────────────────────

function updateStoredStats() {
  totalStored.textContent = storedTrades.length;
  if (storedTrades.length > 0) btnClear.style.display = "";
}

function setBusy(busy) {
  btnScan.disabled = busy;
  scanSpinner.style.display = busy ? "block" : "none";
  scanLabel.textContent = busy ? "Scanning…" : "⚡ Scan Trades";
}

function showAlert(msg, type) {
  if (!msg) {
    alertBox.style.display = "none";
    return;
  }
  alertBox.className = `alert ${type}`;
  alertBox.textContent = msg;
  alertBox.style.display = "block";
}

function tradesToCSV(trades) {
  if (!trades.length) return "";

  // Gather all keys across all trades
  const allKeys = new Set();
  trades.forEach((t) => Object.keys(t).forEach((k) => allKeys.add(k)));

  // Preferred column order
  const preferred = [
    "ticket", "openTime", "closeTime", "type", "symbol", "volume",
    "openPrice", "closePrice", "sl", "tp",
    "commission", "fee", "swap", "profit", "comment",
  ];

  const ordered = [
    ...preferred.filter((k) => allKeys.has(k)),
    ...[...allKeys].filter((k) => !preferred.includes(k)).sort(),
  ];

  const escape = (v) => {
    if (v === undefined || v === null) return "";
    const s = String(v);
    if (s.includes(",") || s.includes('"') || s.includes("\n")) {
      return `"${s.replace(/"/g, '""')}"`;
    }
    return s;
  };

  const header = ordered.map(escape).join(",");
  const rows = trades.map((t) => ordered.map((k) => escape(t[k])).join(","));
  return [header, ...rows].join("\n");
}

function renderPreview(trades) {
  if (!trades.length) {
    previewWrap.innerHTML = '<div class="preview-empty">No trades to preview</div>';
    totalSelected.textContent = "0";
    return;
  }

  // Set up default selections (all rendered trades are selected by default)
  selectedKeys.clear();
  trades.forEach(t => selectedKeys.add(`${t.ticket}_${t.openTime}`));
  totalSelected.textContent = selectedKeys.size;

  const cols = ["ticket", "type", "symbol", "volume", "openPrice", "profit"];
  const colLabels = { ticket: "Ticket", type: "Type", symbol: "Symbol", volume: "Vol", openPrice: "Price", profit: "P/L" };

  const visibleCols = cols.filter((c) => trades.some((t) => t[c] !== undefined && t[c] !== ""));

  let html = '<table class="preview-table"><thead><tr>';
  
  // Add select-all checkbox column header
  html += '<th style="width: 30px; text-align: center;"><input type="checkbox" id="selectAllTrades" checked style="cursor:pointer;" /></th>';

  visibleCols.forEach((c) => {
    html += `<th>${colLabels[c] || c}</th>`;
  });
  html += "</tr></thead><tbody>";

  for (const t of trades) {
    const key = `${t.ticket}_${t.openTime}`;
    html += `<tr data-key="${key}">`;
    
    // Add row checkbox cell
    html += `<td style="text-align: center;"><input type="checkbox" class="trade-selector-cb" data-key="${key}" checked style="cursor:pointer;" /></td>`;

    for (const c of visibleCols) {
      let val = t[c] !== undefined ? t[c] : "–";
      let cls = "";

      if (c === "type") {
        cls = val === "buy" ? "tag-buy" : val === "sell" ? "tag-sell" : "";
        val = val ? val.toUpperCase() : "–";
      }

      if (c === "profit") {
        const n = parseFloat(val);
        if (!isNaN(n)) {
          cls = n >= 0 ? "profit-pos" : "profit-neg";
          val = (n >= 0 ? "+" : "") + n.toFixed(2);
        }
      }

      if (c === "ticket" && String(val).length > 8) {
        val = "…" + String(val).slice(-6);
      }

      html += `<td class="${cls}">${val}</td>`;
    }
    html += "</tr>";
  }

  html += "</tbody></table>";
  previewWrap.innerHTML = html;

  // Bind checkbox events
  const selectAllCb = document.getElementById("selectAllTrades");
  const rowCbs = document.querySelectorAll(".trade-selector-cb");

  const updateButtonsState = () => {
    const noneSelected = selectedKeys.size === 0;
    btnCopyCsv.disabled = noneSelected;
    btnCopyJson.disabled = noneSelected;
  };

  selectAllCb.addEventListener("change", (e) => {
    const checked = e.target.checked;
    rowCbs.forEach(cb => {
      cb.checked = checked;
      const key = cb.getAttribute("data-key");
      if (checked) {
        selectedKeys.add(key);
      } else {
        selectedKeys.delete(key);
      }
    });
    totalSelected.textContent = selectedKeys.size;
    updateButtonsState();
  });

  rowCbs.forEach(cb => {
    cb.addEventListener("change", (e) => {
      const checked = e.target.checked;
      const key = cb.getAttribute("data-key");
      if (checked) {
        selectedKeys.add(key);
      } else {
        selectedKeys.delete(key);
      }
      
      const allChecked = Array.from(rowCbs).every(r => r.checked);
      const someChecked = Array.from(rowCbs).some(r => r.checked);
      selectAllCb.checked = allChecked;
      selectAllCb.indeterminate = !allChecked && someChecked;

      totalSelected.textContent = selectedKeys.size;
      updateButtonsState();
    });
  });
}

function sortTradesNewestFirst(list) {
  if (!Array.isArray(list)) return [];
  return list.sort((a, b) => {
    const timeA = a.closeTime || a.openTime || '';
    const timeB = b.closeTime || b.openTime || '';
    if (timeA < timeB) return 1;
    if (timeA > timeB) return -1;
    return 0;
  });
}

function isActualTrade(t) {
  if (!t) return false;
  if (!t.ticket) return false;
  const ticketStr = String(t.ticket).trim();
  
  // Strip leading/trailing ellipses, dots, and spaces
  const cleanedTicket = ticketStr.replace(/^[.\s…]+|[.\s…]+$/g, '').replace(/\s/g, '');
  
  // Real ticket number never contains a minus sign or a decimal point
  if (/[.\-–—]/.test(cleanedTicket)) return false;
  
  // Must be a pure digit string of at least 5 digits
  if (!/^\d{5,}$/.test(cleanedTicket)) return false;
  
  const ignoreTypes = ["balance", "deposit", "credit", "withdrawal"];
  if (t.type && ignoreTypes.includes(t.type.toLowerCase().trim())) return false;
  
  return true;
}

function getSlicedTrades(list, limit) {
  if (!limit) return list;
  return list.slice(0, limit);
}
