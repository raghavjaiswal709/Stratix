// MT5 Trade Extractor - Content Script
// Scrapes trade history from MetaTrader 5 Web Terminal

(function () {
  "use strict";

  // Listen for messages from the popup
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "extractTrades") {
      const count = request.count; // number of trades to extract (null = all)
      const historical = !!request.historical;
      
      // Auto-scroll logic if requested
      if (request.autoScroll) {
        // Acknowledge receipt from this frame
        chrome.runtime.sendMessage({ action: "extractAck" });
        
        autoScrollAndExtract(count, historical).then((trades) => {
          chrome.runtime.sendMessage({ action: "tradesExtracted", trades: trades, isFinal: true });
        }).catch((err) => {
          chrome.runtime.sendMessage({ action: "tradesExtracted", trades: [], isFinal: true, error: err.message });
        });
        return false; // Do not use sendResponse
      }

      // Legacy synchronous extract
      const trades = extractTradesFromPage(count, historical);
      if (trades.length > 0) {
        chrome.runtime.sendMessage({ action: "tradesExtracted", trades: trades, isFinal: true });
      } else {
        chrome.runtime.sendMessage({ action: "tradesExtracted", trades: [], isFinal: true });
      }
      return false;
    } else if (request.action === "ping") {
      sendResponse({ alive: true });
    }
    return true; // keep message channel open for async
  });

  function extractTradesFromPage(count, historical = false) {
    let trades = [];

    if (historical) {
      // ─── Strategy -1: Column-position-aware structured extractor ───
      // This is the most accurate path. It reads the trade table/grid by COLUMN
      // INDEX while PRESERVING empty cells (blank S/L, T/P, Fee, Swap), so the
      // money columns (commission / fee / swap / profit) never shift left when a
      // cell is blank — the bug that previously scrambled commission & swap and
      // corrupted the profit totals.
      trades = tryExtractStructured();

      // ─── Strategy 0: AG Grid (MT5 Web Terminal) ───
      if (trades.length === 0) {
        trades = tryExtractFromAgGrid();
      }
    }

    // ─── Strategy 1: Heuristic DOM Row Scraper (Super robust) ───
    if (trades.length === 0) {
      trades = tryExtractFromHeuristicDOM();
    }

    // ─── Strategy 2: MT5 Web Terminal (metatrader5.com / official web) ───
    if (trades.length === 0) {
      trades = tryExtractFromWebTerminal();
    }

    // ─── Strategy 3: Generic table rows if Strategy 2 fails ───
    if (trades.length === 0) {
      trades = tryExtractFromGenericTable();
    }

    // ─── Strategy 4: Scrape visible text and parse manually ───
    if (trades.length === 0) {
      trades = tryExtractFromVisibleText();
    }

    // Filter trades based on whether Historical option is enabled
    if (historical) {
      // Filter out non-trade balance modifications and ensure trade is historical/closed
      const ignoreTypes = ["balance", "deposit", "credit", "withdrawal"];
      trades = trades.filter((t) => 
        (t.ticket || t.openTime || t.closeTime || t.symbol) && 
        (!t.type || !ignoreTypes.includes(t.type.toLowerCase().trim())) &&
        (t.closeTime || t.closePrice !== undefined)
      );
    } else {
      // Look for default listed trades with NO filters
      trades = trades.filter((t) => (t.ticket || t.openTime || t.closeTime || t.symbol));
    }

    // Sort newest first (latest to oldest based on closeTime, then openTime)
    trades.sort((a, b) => {
      const timeA = a.closeTime || a.openTime || '';
      const timeB = b.closeTime || b.openTime || '';
      if (timeA < timeB) return 1;
      if (timeA > timeB) return -1;
      return 0;
    });

    if (count && count > 0) {
      trades = trades.slice(0, count);
    }

    return trades;
  }

  // ─── Auto-scroll Logic ──────────────────────────────────────────────────
  async function autoScrollAndExtract(count, historical = false) {
    let allTrades = [];
    const seenKeys = new Set();
    
    // Find the scroll container
    let scrollContainer = findScrollContainer();
    if (!scrollContainer) {
      // Fallback: just extract once if no scroll container is found
      return extractTradesFromPage(count, historical);
    }

    // Scroll to the very top first
    scrollContainer.scrollTop = 0;
    await new Promise(r => setTimeout(r, 500)); // wait for DOM to update
    
    let previousScrollTop = -1;
    let noChangeCount = 0;

    // Loop to scroll and extract
    while (true) {
      // Extract current visible trades
      const currentTrades = extractTradesFromPage(null, historical);
      for (const t of currentTrades) {
        const key = `${t.ticket}_${t.openTime}`;
        if (!seenKeys.has(key)) {
          seenKeys.add(key);
          allTrades.push(t);
        }
      }

      // Check if we reached the count
      if (count && allTrades.length >= count) {
        break;
      }

      // Scroll down by almost the container's height
      const currentScrollTop = scrollContainer.scrollTop;
      const scrollStep = Math.max(100, scrollContainer.clientHeight - 50);
      scrollContainer.scrollTop += scrollStep;
      
      await new Promise(r => setTimeout(r, 600)); // wait for new rows to render

      // Break if we are at the bottom and scrollTop didn't change
      if (Math.abs(scrollContainer.scrollTop - currentScrollTop) < 2) {
        noChangeCount++;
        if (noChangeCount >= 2) break; // If it didn't change twice, we are really at the bottom
      } else {
        noChangeCount = 0;
      }
    }

    // Sort newest first
    allTrades.sort((a, b) => {
      const timeA = a.closeTime || a.openTime || '';
      const timeB = b.closeTime || b.openTime || '';
      if (timeA < timeB) return 1;
      if (timeA > timeB) return -1;
      return 0;
    });

    if (count && count > 0) {
      allTrades = allTrades.slice(0, count);
    }

    return allTrades;
  }

  function findScrollContainer() {
    // 1. Try to find the container using heuristic DOM rows
    const ticketRegex = /\b\d{7,10}\b/;
    const typeRegex = /\b(buy|sell|balance|deposit|credit)\b/i;
    const allElements = document.getElementsByTagName("*");
    let candidateRow = null;

    for (let i = 0; i < allElements.length; i++) {
      const el = allElements[i];
      if (el.children.length === 0) {
        const text = el.innerText ? el.innerText.trim() : "";
        if (ticketRegex.test(text)) {
          let parent = el.parentElement;
          let level = 0;
          while (parent && level < 4) {
            const parentText = parent.innerText || "";
            const tickets = parentText.match(/\b\d{6,10}\b/g);
            if (tickets && tickets.length > 1) break;
            if (typeRegex.test(parentText)) {
              candidateRow = parent;
              break;
            }
            parent = parent.parentElement;
            level++;
          }
          if (candidateRow) break;
        }
      }
    }

    // 2. Traverse up from candidate row to find a scrollable element
    let parent = candidateRow ? candidateRow.parentElement : null;
    while (parent) {
      if (parent.scrollHeight > parent.clientHeight + 5) {
        const style = window.getComputedStyle(parent);
        if (style.overflowY === 'auto' || style.overflowY === 'scroll' || style.overflow === 'auto' || style.overflow === 'overlay') {
          return parent;
        }
      }
      parent = parent.parentElement;
    }
    
    // 3. Fallback to generic known container classes
    const fallbackContainers = document.querySelectorAll(".ag-body-viewport, .ag-center-cols-viewport, [class*='scroll'], [class*='history']");
    for (const el of fallbackContainers) {
       if (el.scrollHeight > el.clientHeight + 5) {
           return el;
       }
    }

    // 4. Fallback to document scroll
    if (document.documentElement.scrollHeight > document.documentElement.clientHeight) return document.documentElement;
    if (document.body.scrollHeight > document.body.clientHeight) return document.body;
    
    return null;
  }

  // ─── Robust number cleaner ──────────────────────────────────────────────
  // MT5 uses a SPACE as the thousands separator ("4 550.13") and "." for the
  // decimal. parseFloat("4 550.13") === 4, so we must strip spaces & thousands
  // commas before parsing. Returns undefined for blank/non-numeric cells so a
  // blank column stays blank instead of defaulting to 0.
  function cleanNumber(s) {
    if (s == null) return undefined;
    let str = String(s).trim();
    if (str === "" || str === "—" || str === "-" || str === "–") return undefined;
    // Remove spaces (thin/regular) used as thousand separators and grouping commas
    str = str.replace(/[\s  ]/g, "").replace(/,/g, "");
    const m = str.match(/-?\d+(?:\.\d+)?/);
    if (!m) return undefined;
    const n = parseFloat(m[0]);
    return isNaN(n) ? undefined : n;
  }

  // Header text → trade field. Duplicate "Time"/"Price" are resolved
  // positionally (1st = open, 2nd = close) via the running `counts` object.
  const STRUCT_HEADER_MAP = {
    ticket: "ticket", order: "ticket", deal: "ticket", id: "ticket", position: "ticket",
    type: "type", direction: "type", side: "type",
    volume: "volume", lots: "volume", size: "volume", "lot": "volume",
    symbol: "symbol", instrument: "symbol", asset: "symbol",
    "s/l": "sl", "s / l": "sl", sl: "sl", "stop loss": "sl", "stoploss": "sl",
    "t/p": "tp", "t / p": "tp", tp: "tp", "take profit": "tp", "takeprofit": "tp",
    commission: "commission", comm: "commission",
    fee: "fee", fees: "fee",
    swap: "swap", rollover: "swap",
    profit: "profit", "net profit": "profit", pnl: "profit", "p/l": "profit", "p / l": "profit", result: "profit",
    comment: "comment", note: "comment", reason: "comment",
  };

  function headerToField(headerText, counts) {
    const h = headerText.toLowerCase().trim().replace(/\s+/g, " ");
    if (!h) return null;
    if (h === "time" || h === "open time" || h === "close time" || h === "open date" || h === "close date" || h === "date") {
      if (/open/.test(h)) return "openTime";
      if (/close/.test(h)) return "closeTime";
      counts.time = (counts.time || 0) + 1;
      return counts.time === 1 ? "openTime" : "closeTime";
    }
    if (h === "price" || h === "open price" || h === "close price" || h === "entry price" || h === "exit price") {
      if (/open|entry/.test(h)) return "openPrice";
      if (/close|exit/.test(h)) return "closePrice";
      counts.price = (counts.price || 0) + 1;
      return counts.price === 1 ? "openPrice" : "closePrice";
    }
    return STRUCT_HEADER_MAP[h] || null;
  }

  // Fields that must be parsed as numbers.
  const NUMERIC_FIELDS = new Set([
    "volume", "openPrice", "closePrice", "sl", "tp",
    "commission", "fee", "swap", "profit",
  ]);

  function buildTradeFromCells(fields, cells) {
    const trade = {};
    const n = Math.min(fields.length, cells.length);
    for (let i = 0; i < n; i++) {
      const field = fields[i];
      if (!field) continue;
      const raw = (cells[i] == null ? "" : String(cells[i])).trim();
      if (raw === "") continue; // preserve "blank" → leave field unset
      if (NUMERIC_FIELDS.has(field)) {
        const v = cleanNumber(raw);
        if (v !== undefined) trade[field] = v;
      } else if (field === "type") {
        trade.type = raw.toLowerCase();
      } else if (field === "symbol") {
        trade.symbol = raw.toUpperCase();
      } else {
        trade[field] = raw;
      }
    }
    return trade;
  }

  // Get a row's cells preserving EMPTY cells (one entry per column).
  function getRowCells(row) {
    // Prefer real grid/table cells so empty columns keep their slot.
    let cellEls = row.querySelectorAll(
      ':scope > td, :scope > th, :scope > [role="gridcell"], :scope > [role="cell"], :scope > .ag-cell'
    );
    if (cellEls.length === 0) {
      cellEls = row.querySelectorAll('td, th, [role="gridcell"], [role="cell"], .ag-cell');
    }
    if (cellEls.length === 0) return null;
    // If ag-grid exposes column indices, order by them for safety.
    const arr = Array.from(cellEls);
    const haveColIdx = arr.every((c) => c.getAttribute && c.getAttribute("aria-colindex"));
    if (haveColIdx) {
      arr.sort(
        (a, b) =>
          parseInt(a.getAttribute("aria-colindex")) -
          parseInt(b.getAttribute("aria-colindex"))
      );
    }
    return arr.map((c) => (c.innerText || c.textContent || "").trim());
  }

  function getHeaderTexts(container) {
    let headerEls = container.querySelectorAll(
      'thead th, thead td, [role="columnheader"], .ag-header-cell'
    );
    if (headerEls.length === 0) {
      const firstRow = container.querySelector("tr");
      if (firstRow) headerEls = firstRow.querySelectorAll("th, td");
    }
    return Array.from(headerEls)
      .map((h) => {
        const t = h.querySelector(".ag-header-cell-text");
        return ((t ? t.innerText : h.innerText) || h.textContent || "").trim();
      });
  }

  // ─── Strategy -1: Column-position-aware structured extractor ─────────────
  function tryExtractStructured() {
    const trades = [];

    // Candidate containers: real tables, ARIA grids, ag-grid roots.
    const containers = [
      ...document.querySelectorAll("table"),
      ...document.querySelectorAll('[role="grid"], [role="table"]'),
      ...document.querySelectorAll(".ag-root, .ag-root-wrapper"),
    ];

    for (const container of containers) {
      const headerTexts = getHeaderTexts(container);
      if (headerTexts.length < 4) continue;

      // Map headers → fields (duplicate-aware).
      const counts = {};
      const fields = headerTexts.map((h) => headerToField(h, counts));

      // Confirm this looks like a trade table.
      const hasTicket = fields.includes("ticket");
      const hasProfit = fields.includes("profit");
      const hasType = fields.includes("type");
      if (!(hasTicket && (hasProfit || hasType))) continue;

      // Data rows (exclude header rows).
      let rowEls = container.querySelectorAll(
        'tbody tr, [role="row"], .ag-row:not(.ag-row-empty)'
      );
      if (rowEls.length === 0) {
        rowEls = container.querySelectorAll("tr");
      }

      const containerTrades = [];
      let attemptedRows = 0;
      for (const row of rowEls) {
        if (row.querySelector("th") && !row.querySelector("td")) continue; // header row
        if (row.closest("thead, .ag-header")) continue;
        const cells = getRowCells(row);
        if (!cells || cells.length < 4) continue;
        attemptedRows++;

        const trade = buildTradeFromCells(fields, cells);
        // Require at least a ticket or a timestamp + a money value.
        if (!trade.ticket && !trade.openTime) continue;
        if (trade.profit === undefined && trade.closePrice === undefined && !trade.openPrice) continue;
        containerTrades.push(trade);
      }

      // Quality gate: a correctly-read trade table has most rows carrying BOTH a
      // ticket and a profit. AG-Grid splits a logical row across pinned/center
      // viewports, producing partial rows — reject those and let a later
      // strategy handle it instead of emitting corrupt half-rows.
      const complete = containerTrades.filter(
        (t) => t.ticket && t.profit !== undefined
      ).length;
      const enough =
        containerTrades.length >= 1 &&
        complete >= Math.max(1, Math.floor(containerTrades.length * 0.5));

      if (enough) {
        for (const t of containerTrades) trades.push(t);
        return trades; // first confident container wins
      }
    }

    return trades;
  }

  // ─── Strategy 0: AG Grid ───────────────────────────────────────────────
  function tryExtractFromAgGrid() {
    const trades = [];
    const grids = document.querySelectorAll(".ag-root, .ag-root-wrapper");
    if (grids.length === 0) return trades;

    for (const grid of grids) {
      // Get headers
      const headerCells = Array.from(grid.querySelectorAll(".ag-header-row:not(.ag-header-row-column-filter) .ag-header-cell"));
      const headers = headerCells.map(h => {
        const textNode = h.querySelector(".ag-header-cell-text");
        return textNode ? textNode.innerText.trim() : h.innerText.trim();
      }).filter(h => h.length > 0);
      
      if (headers.length === 0) continue;

      // Get rows
      const rows = grid.querySelectorAll(".ag-row:not(.ag-row-empty)");
      for (const row of rows) {
        // Use ag-cell
        const cells = Array.from(row.querySelectorAll(".ag-cell")).map(c => c.innerText.trim());
        if (cells.length < 3) continue;
        
        const trade = mapByHeaders(headers, cells);
        if (trade) trades.push(trade);
      }
    }
    return trades;
  }

  // ─── Strategy 1: MT5 official web terminal selectors ───────────────────
  function tryExtractFromWebTerminal() {
    const trades = [];

    // MT5 web uses various class names — we try the most common ones
    const rowSelectors = [
      "tr.terminal-history-row",
      "tr[data-id]",
      ".wt-deal",
      ".history-row",
      "tr.tr-trade",
      ".trade-row",
      "[class*='history'] tr",
      "[class*='deals'] tr",
      "[class*='terminal'] tbody tr",
    ];

    let rows = [];
    for (const sel of rowSelectors) {
      const found = document.querySelectorAll(sel);
      if (found.length > 0) {
        rows = Array.from(found);
        break;
      }
    }

    for (const row of rows) {
      const cells = Array.from(row.querySelectorAll("td, .cell, [class*='cell']"));
      if (cells.length < 3) continue;

      const text = cells.map((c) => c.innerText.trim());
      const trade = parseCellsToTrade(text);
      if (trade) trades.push(trade);
    }

    return trades;
  }

  // ─── Strategy 2: Any HTML table that looks like trades ─────────────────
  function tryExtractFromGenericTable() {
    const trades = [];
    const tables = document.querySelectorAll("table");

    for (const table of tables) {
      const headers = Array.from(
        table.querySelectorAll("thead th, thead td, tr:first-child th, tr:first-child td")
      ).map((h) => h.innerText.trim().toLowerCase());

      // Check if this looks like a trade table
      const tradeKeywords = ["ticket", "time", "type", "symbol", "price", "profit", "volume", "lot"];
      const matches = tradeKeywords.filter((k) => headers.some((h) => h.includes(k)));
      if (matches.length < 2) continue;

      const bodyRows = table.querySelectorAll("tbody tr, tr:not(:first-child)");
      for (const row of bodyRows) {
        const cells = Array.from(row.querySelectorAll("td")).map((c) => c.innerText.trim());
        if (cells.length < 3) continue;
        const trade = mapByHeaders(headers, cells);
        if (trade) trades.push(trade);
      }
    }

    return trades;
  }

  // ─── Strategy 3: Parse visible text blocks ─────────────────────────────
  function tryExtractFromVisibleText() {
    const trades = [];

    // Look for elements that contain trade-like data patterns
    // Pattern: timestamp + ticket + buy/sell + volume + symbol + price
    const allText = document.body.innerText;
    const lines = allText.split("\n").map((l) => l.trim()).filter((l) => l.length > 5);

    // Find lines that look like trade rows
    // e.g. "2026.05.29 15:52:19  7231260  buy  0.05  XAUUSD.  4520.180  4512.656  4531.649"
    const tradePattern =
      /(\d{4}\.\d{2}\.\d{2}\s+\d{2}:\d{2}:\d{2})\s+(\d{5,})\s+(buy|sell|balance)\s+([\d.]+)?\s*([A-Z]{2,}[.\w]*)?/i;

    for (const line of lines) {
      const match = line.match(tradePattern);
      if (match) {
        const parts = line.split(/\s{2,}|\t/).filter((p) => p.trim());
        const trade = parseCellsToTrade(parts);
        if (trade) trades.push(trade);
      }
    }

    return trades;
  }

  // ─── Cell → Trade object mapper ────────────────────────────────────────
  // ─── Strategy 1: Heuristic DOM Row Scraper (Super robust) ─────────────
  function tryExtractFromHeuristicDOM() {
    const trades = [];
    const ticketRegex = /\b\d{7,10}\b/;
    const typeRegex = /\b(buy|sell|balance|deposit|credit)\b/i;

    const allElements = document.getElementsByTagName("*");
    const candidateRows = new Set();

    for (let i = 0; i < allElements.length; i++) {
      const el = allElements[i];
      if (el.children.length === 0) {
        const text = el.innerText ? el.innerText.trim() : "";
        if (ticketRegex.test(text)) {
          let parent = el.parentElement;
          let level = 0;
          let bestRow = null;
          while (parent && level < 4) {
            const parentText = parent.innerText || "";
            // If the parent wraps multiple tickets, we stop going up to prevent cross-row contamination
            const tickets = parentText.match(/\b\d{6,10}\b/g);
            if (tickets && tickets.length > 1) {
              break;
            }
            if (typeRegex.test(parentText)) {
              bestRow = parent;
            }
            parent = parent.parentElement;
            level++;
          }
          if (bestRow) {
            candidateRows.add(bestRow);
          }
        }
      }
    }

    candidateRows.forEach((row) => {
      const cellTexts = [];
      const walk = document.createTreeWalker(row, NodeFilter.SHOW_TEXT, null, false);
      let node;
      while (node = walk.nextNode()) {
        const val = node.nodeValue.trim();
        if (val.length > 0) {
          cellTexts.push(val);
        }
      }

      if (cellTexts.length >= 3) {
        const trade = parseCellsToTrade(cellTexts);
        if (trade) {
          trades.push(trade);
        }
      }
    });

    return trades;
  }

  // ─── Cell → Trade object mapper ────────────────────────────────────────
  function parseCellsToTrade(cells) {
    if (!cells || cells.length < 3) return null;

    const trade = {};
    const timestamps = [];
    let closeTimeCellIdx = -1;
    
    // 1. Find timestamps and their indices
    for (let i = 0; i < cells.length; i++) {
      const c = cells[i];
      if (/\d{4}[.\-\/]\d{2}[.\-\/]\d{2}/.test(c) || /\d{2}[.\-\/]\d{2}[.\-\/]\d{2,4}/.test(c)) {
        let ts = c;
        let consumedNext = false;
        if (i + 1 < cells.length && /^\d{2}:\d{2}(:\d{2})?$/.test(cells[i + 1])) {
          ts += " " + cells[i + 1];
          consumedNext = true;
        }
        timestamps.push(ts);
        if (timestamps.length === 1) trade.openTime = ts;
        if (timestamps.length === 2) {
          trade.closeTime = ts;
          closeTimeCellIdx = consumedNext ? i + 1 : i;
        }
        if (consumedNext) i++;
      }
    }

    // 2. Ticket
    const ticketIdx = cells.findIndex((c) => /^\d{6,}$/.test(c.replace(/\s/g, "")));
    if (ticketIdx >= 0) trade.ticket = cells[ticketIdx].replace(/\s/g, "");

    // 3. Type
    const typeIdx = cells.findIndex((c) => /^(buy|sell|balance|deposit|credit)$/i.test(c.trim()));
    if (typeIdx >= 0) trade.type = cells[typeIdx].toLowerCase().trim();

    // 4. Symbol
    const symbolIdx = cells.findIndex((c) => {
      const val = c.trim().toUpperCase();
      return /^[A-Z]{2,6}([A-Z0-9_+#.]{1,6})?$/.test(val) && val.length >= 3 && !/^(BUY|SELL|BALANCE|DEPOSIT|CREDIT)$/.test(val);
    });
    if (symbolIdx >= 0) trade.symbol = cells[symbolIdx].trim().toUpperCase();

    // Helper to extract numbers from a slice of cells
    const getNumbers = (start, end) => {
      const nums = [];
      for(let i = start; i <= end; i++) {
        if (cells[i] === undefined || cells[i] === null) continue;
        if (i === ticketIdx) continue;
        if (timestamps.some(ts => ts.includes(cells[i]))) continue;
        if (symbolIdx === i) continue;
        if (typeIdx === i) continue;
        
        const val = parseFloat(cells[i].replace(/\s/g, "").replace(",", "."));
        if (!isNaN(val)) nums.push(val);
      }
      return nums;
    };

    // 5. Split numbers into before and after close time
    let headNumbers = [];
    let tailNumbers = [];

    if (closeTimeCellIdx !== -1) {
      headNumbers = getNumbers(0, closeTimeCellIdx - 1);
      tailNumbers = getNumbers(closeTimeCellIdx + 1, cells.length - 1);
    } else {
      headNumbers = getNumbers(0, cells.length - 1);
    }

    // Process head numbers: Volume, OpenPrice, [SL], [TP]
    if (headNumbers.length > 0) trade.volume = headNumbers[0];
    if (headNumbers.length > 1) trade.openPrice = headNumbers[1];
    
    // If we have 4 head numbers, it's definitely SL and TP
    if (headNumbers.length >= 4) {
      trade.sl = headNumbers[2];
      trade.tp = headNumbers[3];
    } 
    // If we have 3, we don't know if it's SL or TP, default to SL (most common to have SL only)
    else if (headNumbers.length === 3) {
      trade.sl = headNumbers[2];
    }

    // Process tail numbers: ClosePrice, [Commission], [Fee], [Swap], Profit
    if (tailNumbers.length > 0) {
      trade.closePrice = tailNumbers[0];
      
      if (tailNumbers.length >= 2) {
        trade.profit = tailNumbers[tailNumbers.length - 1];
      }
      
      const middleCount = tailNumbers.length - 2;
      if (middleCount === 1) {
        trade.commission = tailNumbers[1];
      } else if (middleCount === 2) {
        trade.commission = tailNumbers[1];
        trade.swap = tailNumbers[2]; // usually fee is empty, swap is present
      } else if (middleCount >= 3) {
        trade.commission = tailNumbers[1];
        trade.fee = tailNumbers[2];
        trade.swap = tailNumbers[3];
      }
    } else if (closeTimeCellIdx === -1 && headNumbers.length > 2) {
        // Active trade, no close time. Last number is profit.
        trade.profit = headNumbers[headNumbers.length - 1];
    }

    // Comment
    const lastCell = cells[cells.length - 1];
    if (lastCell && isNaN(parseFloat(lastCell)) && lastCell.length > 0 && symbolIdx !== cells.length - 1) {
      trade.comment = lastCell.trim();
    }

    if (!trade.ticket && !trade.openTime) return null;
    return trade;
  }

  // ─── Map table cells to trade using header names ────────────────────────
  function mapByHeaders(headers, cells) {
    if (headers.length === 0 || cells.length === 0) return null;

    const trade = {};
    const headerMap = {
      time: "openTime",
      "open time": "openTime",
      "open date": "openTime",
      ticket: "ticket",
      order: "ticket",
      deal: "ticket",
      id: "ticket",
      type: "type",
      direction: "type",
      volume: "volume",
      lots: "volume",
      size: "volume",
      symbol: "symbol",
      instrument: "symbol",
      asset: "symbol",
      price: "openPrice",
      "open price": "openPrice",
      "entry price": "openPrice",
      "s/l": "sl",
      "s / l": "sl",
      sl: "sl",
      "stop loss": "sl",
      "t/p": "tp",
      "t / p": "tp",
      tp: "tp",
      "take profit": "tp",
      "close time": "closeTime",
      "exit time": "closeTime",
      "close price": "closePrice",
      "exit price": "closePrice",
      commission: "commission",
      fee: "fee",
      swap: "swap",
      profit: "profit",
      "net profit": "profit",
      pnl: "profit",
      comment: "comment",
      note: "comment",
    };

    let timeCount = 0;
    let priceCount = 0;

    for (let i = 0; i < Math.min(headers.length, cells.length); i++) {
      let h = headers[i].toLowerCase().trim().replace(/\s+/g, ' ');
      let key = headerMap[h] || h;

      if (h === "time") {
        timeCount++;
        if (timeCount === 1) key = "openTime";
        else if (timeCount === 2) key = "closeTime";
      }
      if (h === "price") {
        priceCount++;
        if (priceCount === 1) key = "openPrice";
        else if (priceCount === 2) key = "closePrice";
      }

      if (cells[i] !== undefined && cells[i] !== "") {
        if (NUMERIC_FIELDS.has(key)) {
          const v = cleanNumber(cells[i]);
          if (v !== undefined) trade[key] = v;
        } else if (key === "type") {
          trade.type = String(cells[i]).toLowerCase().trim();
        } else if (key === "symbol") {
          trade.symbol = String(cells[i]).toUpperCase().trim();
        } else {
          trade[key] = cells[i];
        }
      }
    }

    return Object.keys(trade).length > 0 ? trade : null;
  }
})();
